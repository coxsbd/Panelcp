<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
$values = array();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
}else{
	echo "<script> swal({ title: 'Error!' , text: 'Sorry, you dont have permission to access this page.', button: false, closeOnClickOutside: false, icon: 'error' })  </script>";
	$db->RedirectToURL($db->base_url());
	exit;
}

// A server counts as ACTIVE only when one of its SERVICE ports answers.
// Port 22 (SSH) is NOT counted: it is open on a brand-new VPS before the
// installer has run, which made servers show ACTIVE too early.
function server_is_up($row) {
	$host  = $row['server_ip'];
	$ports = array(8080, 80, 443, 442, 1194);
	foreach (array('port_tcp') as $col) {
		if (isset($row[$col]) && ctype_digit(trim((string)$row[$col]))) {
			$ports[] = (int)trim($row[$col]);
		}
	}
	$ports = array_unique($ports);
	foreach ($ports as $p) {
		if ($p == 22) { continue; }
		$fp = @fsockopen($host, $p, $errno, $errstr, 3);
		if ($fp) {
			fclose($fp);
			return true;
		}
	}
	return false;
}

$server = $db->sql_query("SELECT * FROM server_list");
while($server_row = $db->sql_fetchrow($server))
{
	$server_ip     = $server_row['server_ip'];
	$server_status = (string)$server_row['status'];

	if(server_is_up($server_row)){
		$chk_premium_parser = '1';
	}elseif($server_status === '99' || $server_status === '98'){
		$chk_premium_parser = $server_status;
	}else{
		$chk_premium_parser = '0';
	}

	$db->sql_query("UPDATE server_list SET status = '".$chk_premium_parser."' WHERE server_ip = '".$server_ip."'");
}
?>