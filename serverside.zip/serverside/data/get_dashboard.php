<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '0');
require_once '../../includes/functions.php';
chkSession();

// Allow all user levels
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer' || $user_level_2 == 'reseller' || $user_level_2 == 'normal' || $user_level_2 == 'bulk' || $user_level_2 == 'trial'){
}else{
	ob_end_clean();
	echo "<script> swal({ title: 'Error!' , text: 'Sorry, you dont have permission to access this page.', button: false, closeOnClickOutside: false, icon: 'error' })  </script>";
	$db->RedirectToURL($db->base_url());
	exit;
}

// Initialize arrays to avoid undefined variable errors
$activity = array();
$servers  = array();
$values   = array();
$valid    = true;

//Get Total Resellers
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$qry_reseller = $db->sql_query("SELECT * FROM users WHERE user_level='reseller'");
}else{
	$qry_reseller = $db->sql_query("SELECT * FROM users WHERE user_level='reseller' AND user_id!='$user_id_2' AND upline='$user_id_2'");
}
$reseller = $db->sql_numrows($qry_reseller);

//Get Total Users
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$qry_user = $db->sql_query("SELECT * FROM users WHERE user_level='normal' OR user_level='bulk' OR user_level='trial'");
}else{
	$qry_user = $db->sql_query("SELECT * FROM users WHERE (user_level='normal' OR user_level='bulk' OR user_level='trial') AND user_id!='$user_id_2' AND upline='$user_id_2'");
}
$user = $db->sql_numrows($qry_user);

//Get Total Normal
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$qry_normal = $db->sql_query("SELECT * FROM users WHERE user_level='normal'");
}else{
	$qry_normal = $db->sql_query("SELECT * FROM users WHERE user_level='normal' AND user_id!='$user_id_2' AND upline='$user_id_2'");
}
$normal = $db->sql_numrows($qry_normal);

//Get Total Bulk
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$qry_bulk = $db->sql_query("SELECT * FROM users WHERE user_level='bulk'");
}else{
	$qry_bulk = $db->sql_query("SELECT * FROM users WHERE user_level='bulk' AND user_id!='$user_id_2' AND upline='$user_id_2'");
}
$bulk = $db->sql_numrows($qry_bulk);

//Get Total Trial
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$qry_trial = $db->sql_query("SELECT * FROM users WHERE user_level='trial'");
}else{
	$qry_trial = $db->sql_query("SELECT * FROM users WHERE user_level='trial' AND user_id!='$user_id_2' AND upline='$user_id_2'");
}
$trial = $db->sql_numrows($qry_trial);

//Get Total Server
$q_server   = $db->sql_query("SELECT server_name FROM server_list");
$servercount = $db->sql_numrows($q_server);

if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	if($servercount > 0){
		$qry_online1 = $db->sql_query("SELECT sum(online) as counts FROM server_list WHERE status='1'");
		$rowo1   = $db->sql_fetchrow($qry_online1);
		$online1_ = $rowo1['counts'];

		$qry_online2 = $db->sql_query("SELECT sum(hysteria_online) as counts2 FROM server_list WHERE status='1'");
		$rowo2   = $db->sql_fetchrow($qry_online2);
		$online2_ = $rowo2['counts2'];

		$qry_online3 = $db->sql_query("SELECT sum(ssh_online) as counts3 FROM server_list WHERE status='1'");
		$rowo3   = $db->sql_fetchrow($qry_online3);
		$online3_ = $rowo3['counts3'];

		$online = intval($online1_) + intval($online2_) + intval($online3_);
	}else{
		$online = 0;
	}
}else{
	$qry_online = $db->sql_query("SELECT user_name FROM users WHERE (user_level='normal' OR user_level='bulk' OR user_level='trial') AND active_address!='' AND user_id!='$user_id_2' AND upline='$user_id_2'");
	$online = $db->sql_numrows($qry_online);
}

//Get Account Info
$qry_info  = $db->sql_query("SELECT * FROM users WHERE user_id='".$user_id_2."'");
$info_row  = $db->sql_fetchrow($qry_info);
$my_username = $info_row['user_name'];
$upline      = $info_row['upline'];
$my_credits  = $info_row['credits'];
$my_duration = $info_row['duration'];

//Get Upline Name
$qry_info2 = $db->sql_query("SELECT user_name FROM users WHERE user_id='".$upline."'");
$info2_row = $db->sql_fetchrow($qry_info2);
$my_upline = $info2_row['user_name'];

$credits = ($user_id_2 == 1) ? '99999' : $my_credits;

//Get Activities
$qry_activity = $db->sql_query("SELECT date, device_os, action FROM activity_logs WHERE user_id='$user_id_2' ORDER BY date DESC LIMIT 10");
while($activity_row = $db->sql_fetchrow($qry_activity)){
	$activity_ = $activity_row['action'];
	$date_     = $activity_row['date'];
	$deviceos  = $activity_row['device_os'];
	$logs_date = strtotime($date_);
	$elapse    = $db->time_elapsed_string($logs_date);
	$activity[] = '<tr><td><span class="badge badge-primary">'.$elapse.'</span></td><td>'.$deviceos.'</td><td>'.$activity_.'</td></tr>';
}

//Get Servers
$qry_server = $db->sql_query("SELECT server_name, flag FROM server_list ORDER BY server_id DESC LIMIT 5");
while($server_row = $db->sql_fetchrow($qry_server)){
	$server_name = $server_row['server_name'];
	$server_flag = $server_row['flag'];
	$servers[] = '<li class="list-group-item d-flex justify-content-between align-items-center">'.$server_name.'<span class="flag-icon"><img src="https://flagcdn.com/'.strtolower($server_flag).'.svg" width="35" height="25" alt="flagicon"></span></li>';
}

// Panel License Duration — admin/dev only
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'){
	$apiLink2 = $chk2;
	$api_02   = $db->decrypt_key($apiLink2);
	$linkapi2 = $db->encryptor('decrypt', $api_02);
	$apiURL   = $linkapi2.'&code='.$site_license;

	$curl = curl_init($apiURL);
	curl_setopt($curl, CURLOPT_URL, $apiURL);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	$resp    = curl_exec($curl);
	curl_close($curl);

	$apiData    = json_decode($resp, true);
	$statusCode = $apiData['status'];
	$MSG        = $apiData['msg'];

	if($statusCode === 1){
		$dur      = $db->calc_time($MSG);
		$values['licdur'] = $dur['days'].' Day(s) | '.$dur['hours'].' Hour(s) and '.$dur['minutes'].' Minutes Left';
	}elseif($statusCode === 2){
		$values['licdur'] = $MSG;
	}elseif($statusCode === 3){
		$values['licdur'] = $MSG;
	}
}

// Account Remaining Duration — normal/bulk/trial users
if($user_level_2 == 'normal' || $user_level_2 == 'bulk' || $user_level_2 == 'trial'){
	if($my_duration > 0){
		$dur = $db->calc_time($my_duration);
		$values['user_duration'] = $dur['days'].' Day(s) | '.$dur['hours'].' Hour(s) and '.$dur['minutes'].' Minutes Left';
	}else{
		$values['user_duration'] = 'Expired';
	}
}

if($info_row){
	$values['reseller']         = $reseller;
	$values['user']             = $user;
	$values['normal']           = $normal;
	$values['trial']            = $trial;
	$values['bulk']             = $bulk;
	$values['online']           = $online;
	$values['servercount']      = $servercount;
	$values['profile_username'] = $my_username;
	$values['profile_upline']   = $my_upline;
	$values['profile_credits']  = $credits;
	$values['activity']         = $activity;
	$values['servers']          = $servers; // array of <li> strings, joined client-side
	$values['response']         = 1;
}else{
	$values['response'] = 2;
}

ob_end_clean();
header('Content-Type: application/json');
echo json_encode($values);
?>