<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer' || $user_level_2 == 'reseller'){
}else{
	echo "<script> swal({ title: 'Error!' , text: 'Sorry, you dont have permission to access this page.', button: false, closeOnClickOutside: false, icon: 'error' })  </script>";
	$db->RedirectToURL($db->base_url());
	exit;
}

    $sql = "SELECT * FROM notification ORDER BY date DESC";
    $qry = $db->sql_query("$sql") OR die();
	$total_notif = $db->sql_numrows($qry);
	while($row = $db->sql_fetchrow($qry)){
	    $id = $row['id'];
    	$title = $row['title'];
    	$filename = $row['filename'];
    	$type = $row['type'];
    	$date = $row['date'];
    	$time = get_time_elapsed("$date");
    	
    	if($type == 1){
    	    $icon = '<i class="fas fa-bullhorn"></i>';
    	    $bg = 'bg-primary';
    	    $ntype = 'Info';
    	}elseif($type == 2){
    	    $icon = '<i class="fas fa-bolt"></i>';
			$bg = 'bg-danger';
			$ntype = 'Emergency';
    	}elseif($type == 3){
    	    $icon = '<i class="fas fa-exclamation-triangle"></i>';
			$bg = 'bg-warning';
			$ntype = 'Critical';
    	}
    	
    	$notifica[] = '<a href="javascript:void(0)" class="dropdown-item dropdown-item-unread view-notification" data-type="'.$ntype.'" data-date="'.$time.'" data-id="'.$id.'">
	                        <div class="dropdown-item-icon '.$bg.' text-white"> '.$icon.' </div>
	                        <div class="dropdown-item-desc"> '.$title.' <div class="time text-primary">'.$time.'</div>
	                        </div>
	                    </a>';

	}
	
	$values = array();
	$valid = true;
    
	if($valid == true){
		$values['notifica'] = $notifica;
		$values['notiftotal'] = $total_notif;
		$values['response'] = 1;
	}else{
		$values['response'] = 2;
	}
	if($valid == false){
		$values['response'] = 0;
	}
	echo json_encode($values);

?>