<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
$values = array();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer' || $user_level_2 == 'reseller'){
}else{
	echo "<script> swal({ title: 'Error!' , text: 'Sorry, you dont have permission to access this page.', button: false, closeOnClickOutside: false, icon: 'error' })  </script>";
	$db->RedirectToURL($db->base_url());
	exit;
}
    $apiURL = $site_update;
    $ch = curl_init($apiURL); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $apiResponse = curl_exec($ch); 
    curl_close($ch); 
                
    $apiData = json_decode($apiResponse, true); 
    $list = $apiData['updateList'];
    $elementCount  = count($list);
    
    foreach ($list as $key => $value) {
        $description = $value["description"];
        $update[] = '<li>'.$description.'</li>';
    }
    
    if(!empty($apiData)){ 
        $values['version'] = $apiData['versionCode'];
        $values['versiontype'] = $apiData['versionType'];
        $values['versiontitle'] = $apiData['versionTitle'];
        $values['versionmsg'] = $apiData['versionMSG'];
        $values['content'] = $update;
        $values['length'] = $elementCount;
		$values['response'] = 1;
    }else{
        $values['response'] = 2;
    }
    echo json_encode($values);
?>