<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../includes/functions.php';
chkSession();
$values = array();
if($user_id_2 == 2 || $user_level_2 == 'developer'){
}else{
	echo "<script> swal({ title: 'Error!' , text: 'Sorry, you dont have permission to access this page.', button: false, closeOnClickOutside: false, icon: 'error' })  </script>";
	$db->RedirectToURL($db->base_url());
	exit;
}
    $key = $db->encryptor('decrypt', $_POST['_key']);
	$get_key = $db->Sanitize($key);
	
	$github_username = $db->Sanitize(trim($_POST['github_username']));
	$github_token = $db->Sanitize(trim($_POST['github_token']));
	$update_json = $db->Sanitize(trim($_POST['upnotice']));
	$license = $db->Sanitize(trim($_POST['license']));
	
    if(isset($_POST['submitted'])  == 'git_settings'){
        $valid = true;
        
        if(empty($github_username)){
            $errormsg[] = 'Enter github username.'.PHP_EOL;
            $valid = false;
        }
        
        if(empty($github_token)){
            $errormsg[] = 'Enter github token.'.PHP_EOL;
            $valid = false;
        }
        
        if(empty($update_json)){
            $errormsg[] = 'Enter update link.'.PHP_EOL;
            $valid = false;
        }
        
        if($valid){
            if($get_key == 'firenetdev'){
                
                $update = $db->sql_query("UPDATE site_options SET 
                            github_username='".$db->SanitizeForSQL($github_username)."', github_token='".$db->SanitizeForSQL($github_token)."', update_json='".$db->SanitizeForSQL($update_json)."', license='".$db->SanitizeForSQL($license)."'"); 
                if($update){
                    $success_message = 'Developer settings updated.';
                    $values['response'] = 1;
                    $values['msg'] = $success_message;
                }else{
                    $error_message = 'Failed updating developer settings!';
                    $values['response'] = 2;
                    $values['msg'] = $error_message;
                }
            }else{
                $error_message = 'Site key invalid!';
                $values['response'] = 2;
                $values['msg'] = $error_message;
            }
        }else{
            $values['response'] = 3;
            $errors = implode('',$errormsg);
            $values['errormsg'] = $errors;
        }
    }
    echo json_encode($values);
?>