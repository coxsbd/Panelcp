<?php
chkSession();
if($user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer' || $user_level_2 == 'reseller'){
}else{
    header("Location: /dashboard");
}

function formatBytes($bytes) {
    if($bytes <= 0) return '<span class="badge badge-secondary">0 B</span>';
    $units = ['B','KB','MB','GB','TB'];
    $i = min(floor(log((float)$bytes, 1024)), 4);
    $val = round($bytes / pow(1024, $i), 2);
    return '<span class="badge badge-primary">' . $val . ' ' . $units[$i] . '</span>';
}

function formatSession($seconds) {
    if($seconds <= 0) return '<span class="badge badge-secondary">none</span>';
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    $s = $seconds % 60;
    return '<span class="badge badge-info">' . sprintf('%02d:%02d:%02d', $h, $m, $s) . '</span>';
}

$requestData = $_REQUEST;
if(empty($requestData)){ $db->RedirectToURL($db->base_url()); exit; }

$upline_filter = "";
if($user_level_2 == 'reseller'){
    $upline_filter = " AND u.upline='$user_id_2'";
}

$columns = array(
    0 => 'u.user_id',
    1 => 'u.user_name',
    2 => 'u.login_status',
    3 => 'u.session',
    4 => 'u.bytes_received',
    5 => 'u.duration',
    6 => 'u.user_id'
);

// Total count
$sql = "SELECT COUNT(*) as cnt FROM users u WHERE u.user_id > 1 AND u.user_level!='superadmin' AND u.is_groupname='normal' $upline_filter";
$q = $db->sql_query($sql);
$r = $db->sql_fetchrow($q);
$totalData = intval($r['cnt']);
$totalFiltered = $totalData;

// Search filter
$search_filter = "";
if(!empty($requestData['search']['value'])) {
    $sv = $db->sql_escape($requestData['search']['value']);
    $search_filter = " AND (u.user_name LIKE '%$sv%')";
    $qf = $db->sql_query("SELECT COUNT(*) as cnt FROM users u WHERE u.user_id > 1 AND u.user_level!='superadmin' AND u.is_groupname='normal' $upline_filter $search_filter");
    $rf = $db->sql_fetchrow($qf);
    $totalFiltered = intval($rf['cnt']);
}

$col  = isset($requestData['order'][0]['column']) ? intval($requestData['order'][0]['column']) : 0;
$col  = ($col > 6) ? 0 : $col;
$dir  = (isset($requestData['order'][0]['dir']) && $requestData['order'][0]['dir'] == 'asc') ? 'ASC' : 'DESC';
$start  = intval($requestData['start']);
$length = intval($requestData['length']);

$sql = "SELECT u.* FROM users u WHERE u.user_id > 1 AND u.user_level!='superadmin' AND u.is_groupname='normal' $upline_filter $search_filter ORDER BY " . $columns[$col] . " $dir LIMIT $start, $length";
$query = $db->sql_query($sql) or die();

$data = array();
while($row = $db->sql_fetchrow($query)) {
    $uid      = $row['user_id'];
    $username = htmlspecialchars($row['user_name']);

    // ---- ONLINE: check bandwidth_logs for active session (time_out = 0000) ----
    $bq = $db->sql_query("SELECT id FROM bandwidth_logs WHERE username='$uid' AND status='online' AND time_out='0000-00-00 00:00:00' LIMIT 1");
    $is_online = ($db->sql_numrows($bq) > 0);
    if($is_online) {
        $online = '<span class="badge badge-success"><i class="fas fa-circle"></i> Yes</span>';
    } else {
        $online = '<span class="badge badge-danger"><i class="fas fa-circle"></i> No</span>';
    }

    // ---- SESSION: sum acctsessiontime from radacct for this user ----
    $sq = $db->sql_query("SELECT SUM(acctsessiontime) as total_session FROM radacct WHERE username='$username' AND acctstoptime IS NULL LIMIT 1");
    $sr = $db->sql_fetchrow($sq);
    $session_secs = intval($sr['total_session']);
    // fallback to bandwidth_logs time_in for active session
    if($session_secs <= 0 && $is_online) {
        $sq2 = $db->sql_query("SELECT time_in FROM bandwidth_logs WHERE username='$uid' AND status='online' AND time_out='0000-00-00 00:00:00' ORDER BY id DESC LIMIT 1");
        $sr2 = $db->sql_fetchrow($sq2);
        if($sr2 && $sr2['time_in'] != '0000-00-00 00:00:00') {
            $session_secs = time() - strtotime($sr2['time_in']);
        }
    }
    $session = formatSession($session_secs);

    // ---- USAGE: SUM all bytes from bandwidth_logs for this user_id ----
    $uq = $db->sql_query("SELECT SUM(CAST(bytes_received AS UNSIGNED) + CAST(bytes_sent AS UNSIGNED)) as total FROM bandwidth_logs WHERE username='$uid'");
    $ur = $db->sql_fetchrow($uq);
    $total_bytes = intval($ur['total']);
    // Also add radacct bytes
    $rq = $db->sql_query("SELECT SUM(acctinputoctets + acctoutputoctets) as total FROM radacct WHERE username='$username'");
    $rr = $db->sql_fetchrow($rq);
    $total_bytes += intval($rr['total']);
    $usage = formatBytes($total_bytes);

    // ---- EXPIRATION: duration in seconds → convert to date ----
    $duration = intval($row['duration']);
    if($duration > 0) {
        $days  = floor($duration / 86400);
        $hours = floor(($duration % 86400) / 3600);
        $mins  = floor(($duration % 3600) / 60);
        if($days > 0) {
            $expiration = '<span class="badge badge-success">' . $days . 'd ' . $hours . 'h</span>';
        } else {
            $expiration = '<span class="badge badge-warning">' . $hours . 'h ' . $mins . 'm</span>';
        }
    } else {
        $expiration = '<span class="badge badge-danger">Expired</span>';
    }

    // ---- ACTIONS ----
    $actions = '<button onclick="view_info('.$uid.')" class="btn btn-sm btn-icon btn-primary" title="View"><i class="fas fa-eye"></i></button> '
             . '<button onclick="user_option('.$uid.')" class="btn btn-sm btn-icon btn-warning" title="Edit"><i class="fas fa-edit"></i></button> '
             . '<button onclick="user_option('.$uid.')" class="btn btn-sm btn-icon btn-info" title="Copy"><i class="fas fa-copy"></i></button>';

    $data[] = array($username, $online, $session, $usage, $expiration, $actions);
}

echo json_encode(array(
    "draw"            => intval($requestData['draw']) ? intval($requestData['draw']) : 0,
    "recordsTotal"    => $totalData,
    "recordsFiltered" => $totalFiltered,
    "data"            => $data
));
?>
