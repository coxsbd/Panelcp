<script>
function errorMessage(type,title,message)
{
	$(".errors").html('<div class="alert alert-'+type+' alert-has-icon"><div class="alert-icon"><i class="far fa-lightbulb"></i></div><div class="alert-body"><button class="close" data-dismiss="alert"><span>&times;</span></button><div class="alert-title">'+title+'</div>'+message+'</div></div>').slideDown();
}

function get_credits()
{
    $.ajax({
        url: "{$base_url}serverside/data/get_credits.php",
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
            $('.mycred').val(data.mycredit);
			$('.credits').val(data.mycredit);
			$('.prefix').val(data.prefix);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
    });
}

$(document).ready( function () {

get_credits()

    var $form = $('.addreseller');
	$form.ajaxForm({
		type: "POST",
		url: "{$base_url}serverside/forms/reseller/add_reseller.php",
		data: $form.serialize(),
		dataType: "JSON",
		cache: false,
		beforeSend: function() {
			$(".btn-addreseller").addClass("btn-progress")
		},
		success: function(data){
			if(data.response == 1){
    			errorMessage('success', 'Success', data.msg);
    			$(".addreseller").trigger("reset");
    		}
    		if(data.response == 2){
    			errorMessage('danger','Error', data.msg);
    		}
    		if(data.response == 3){
    			errorMessage('danger','Error', data.errormsg);
    		}
		},
		error: function(jqXHR, textStatus, errorThrown) {
		    gen_user()
			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
		},
		complete: function(){
			$(".btn-addreseller").removeClass("btn-progress")
			get_credits()
		}
	});
	
	
	var $form2 = $('.transfercredit');
	$form2.ajaxForm({
		type: "POST",
		url: "{$base_url}serverside/forms/reseller/transfer_credit.php",
		data: $form2.serialize(),
		dataType: "JSON",
		cache: false,
		beforeSend: function() {
		    $(".btn-transfercredit").addClass("btn-progress");
		},
		success: function(data){
			if(data.response == 1){
    			errorMessage('success', 'Success', data.msg);
    		}
    		if(data.response == 2){
    			errorMessage('danger','Error', data.msg);
    		}
    		if(data.response == 3){
    			errorMessage('danger','Error', data.errormsg);
    		}
		},
		error: function(jqXHR, textStatus, errorThrown) {
			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
		},
		complete: function(){
			$(".btn-transfercredit").removeClass("btn-progress")
			$(".transfercredit").trigger("reset");
			get_credits()
		}
	});
	
	function getD(){
        $.ajax({
            url: "{$base_url}serverside/data/get_data.php",
            type: "GET",
            dataType: "JSON",
        	cache: false,
            success: function(data)
            {
        		if(data.response == 1){
       
                }
                if(data.response == 2){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
                if(data.response == 3){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Error`, `Error parsing data.`, `error`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
        
        	}
        });
    }
    getD()
});
</script>