<script>
function modalize(title, body)
	{
	    $(".modalize").modal({
            backdrop: 'static',
            keyboard: false  // to prevent closing with Esc button (if you want this too)
        })
        $(".modalize").modal('show');
		$(".modal-title").text(title);
		$(".modal-error").html('');
		$(".modal-html").html(body);
	}

function errorMessage(type,title,message)
	{
		$(".modal-body > .modal-error").html('').append('<div class="alert alert-'+type+' alert-has-icon"><div class="alert-icon"><i class="far fa-lightbulb"></i></div><div class="alert-body"><div class="alert-title">'+title+'</div>'+message+'</div></div>').slideDown();
	}

function view_info(u) {
	$.ajax({
        url: "{$base_url}serverside/data/get_userinfo.php",
        data: "uid="+u,
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
            var template_html = `<div class="form-group">
						            <div class="card profile-widget">
                                      <div class="profile-widget-header">
                                        `+data.upic+`
                                        <div class="profile-widget-items">
                                          <div class="profile-widget-item">
                                            <div class="profile-widget-item-label">Normal</div>
                                            <div class="profile-widget-item-value">`+data.dnormal+`</div>
                                          </div>
                                          <div class="profile-widget-item">
                                            <div class="profile-widget-item-label">Bulk</div>
                                            <div class="profile-widget-item-value">`+data.dbulk+`</div>
                                          </div>
                                          <div class="profile-widget-item">
                                            <div class="profile-widget-item-label">Trial</div>
                                            <div class="profile-widget-item-value">`+data.dtrial+`</div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="profile-widget-description">
                                        <div class="form-group"><label for="username">Username</label><input class="form-control" id="username" type="text" value="`+data.username+`" readonly><div>
                                        <div class="form-group mt-2"><label for="password">Password</label><input class="form-control" id="password" type="text" value="`+data.userpass+`" readonly><div>
                                        <div class="form-group mt-2"><label for="upline">Upline</label><input class="form-control" id="upline" type="text" value="`+data.upline+`" readonly><div>
                                      </div>
                                    </div>         
                                </div>`
			modalize('', template_html);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
}

function user_option(u) {
	$.ajax({
        url: "{$base_url}serverside/data/get_reselleroption.php",
        data: "uid="+u,
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
			var template_html = `<div class="form-group">
                            		<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-editcredit" data-id="`+u+`" tabindex="4">Edit Credit</button>
                            		<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-changepassword" data-id="`+u+`" data-username="`+data.username+`" tabindex="4">Change Password</button>
                            		<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-blockreseller" data-id="`+u+`" data-username="`+data.username+`" tabindex="4">Block Reseller</button>
                            		<button type="submit" class="btn btn-danger btn-lg btn-block btn-modal-deletereseller" data-id="`+u+`" data-username="`+data.username+`" tabindex="4">Delete Reseller</button>
                            	</div>`;
			modalize('Actions', template_html);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
}
    
function getResellerData() {
	$.ajax({
        url: "{$base_url}serverside/data/get_myinfo.php",
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
            {if $user_id_2 != 1 || $user_level_2 != 'superadmin'}
    			if (data.mycredit < 5) {
                    $(".accountalert").html(`<div class="alert alert-warning alert-has-icon">
                          <div class="alert-icon"><i class="far fa-lightbulb"></i></div>
                          <div class="alert-body">
                            <div class="alert-title">Ohh no!</div>
                            Your remaining credit balance is getting low, Please contact your upline if you wish to reload.
                          </div>
                        </div>`)
                } else {
                    $(".accountalert").html('')
                }
            {/if}
            $(".profile-username").val(data.myusername)
            $(".profile-credits").val(data.mycredit)
            $(".profile-upline").val(data.myupline)
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
}
	
$('document').ready(function()
{
    function resellerTable() {
        $.fn.dataTable.ext.errMode = () => swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
            button: false,
            closeOnClickOutside: false,
            timer: 3000
        }).then(() => {
            location.reload()
        });
    	$('.table-listreseller').dataTable({
    	    responsive: true,
            "bProcessing": false,
            "bServerSide": true,
            "ajax": {
                "url": "/reseller-serverside",
                "type": "POST"
            },
            "language": {                
                "infoFiltered": ""
            },
            columnDefs: [
                {
                  width: '30%',
                  targets: 0,
                },
                {
                  width: '30%',
                  targets: 1,
                },
                {
                  width: '30%',
                  targets: 2,
                },
                {
                  width: '10%',
                  targets: 3,
                },
                {
                  orderable: false,
                  targets: [1, 2, 3],
                },
            ],
    	});
    }
    
    function reinitializeTable() {
        if ($.fn.DataTable.isDataTable('.table-listreseller')) {
          $('.table-listreseller').DataTable().clear().destroy();
        }
    }
    
    resellerTable()
    getResellerData()
    
    //Edit Credit
    $(".modalize").on("click", ".btn-modal-editcredit", function(e)
	{
		var userid = $(this).data("id");
		$.ajax({
            url: "{$base_url}serverside/data/get_creditinfo.php",
            data: "uid="+userid,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
                var template_html = `<form class="editcreditform" autocomplete="off">` +
                                        `<input type="hidden" name="_key" value="{$firenet_encrypt}">` +
        							    `<input type="hidden" name="id" value="`+userid+`">` +
        							    `<input type="hidden" name="submitted" value="edit_credit">` +
                                        `<div class="form-group"><label for="creditsupline">Your Credit</label><input id="creditsupline" class="form-control" type="text" value="`+data.mycredit+`" readonly></div>` +
                                        `<div class="form-group"><label for="creditsclient">Client Credit</label><input id="creditsclient" class="form-control" type="text" value="`+data.clientcredit+`" readonly></div>` +
                                        `<div class="form-group"><label for="creditamount">Amount</label><input id="creditamount" class="form-control" name="creditamount" type="number" min="0" value="0" required></div>` +
                                        `<div class="form-group"><label>Type</label>` +
                                        `<select class="form-control" name="credittype">` +
                                        `<option value="add">Add</option>` +
                                        `<option value="deduct">Deduct</option>` +
                                        `</select>` +
                                        `</div>` +
                                        `<div class="form-group"><button type="submit" class="btn btn-primary btn-lg btn-block btn-editcredit" tabindex="4">Confirm</button></div>` +
                                        `</form>`;
        		modalize('Edit Credits', template_html);
        		
        		var $form1 = $('.editcreditform');
                	$form1.ajaxForm({
                		type: "POST",
                		url: "{$base_url}serverside/forms/reseller/edit_credit.php",
                		data: $form1.serialize(),
                		dataType: "JSON",
        		        cache: false,
                		beforeSend: function() {
                			$("#btn-editcredit").addClass("btn-progress");
                		},
                		success: function(data){
                			if(data.response == 1){
            					errorMessage('success', 'Success', data.msg);
            					$(".editcreditform").remove();
            				}
            				if(data.response == 2){
            					errorMessage('danger','Error', data.msg);
            				}
            				if(data.response == 3){
            					errorMessage('danger','Error', data.errormsg);
            				}
                		},
                		error: function(jqXHR, textStatus, errorThrown) {
                			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                                button: false,
                                closeOnClickOutside: false,
                                timer: 3000
                            }).then(() => {
                                location.reload()
                            });
                		},
                		complete: function(){
                			$('.table-listreseller').DataTable().ajax.reload();
            				$("#btn-editcredit").removeClass("btn-progress");
                		}
                	});
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
    
    		}
        });
	})
	
	//Change Password
    $(".modalize").on("click", ".btn-modal-changepassword", function(e)
	{
		var userid = $(this).data("id");

		var template_html = `<form class="changepassword" method="post" autocomplete="off">`
						+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
						+ `<input type="hidden" name="id" value="`+userid+`">`
						+ `<input type="hidden" name="submitted" value="change_password">`
						+ `<div class="form-group"><label for="newpassword">New Password</label><input id="newpassword" class="form-control" name="newpassword" type="text"></div>`
						+ `<div class="form-group"><button type="submit" class="btn btn-primary btn-lg btn-block btn-changepass" id="btn-changepass" tabindex="4">Change</button></div>`
						+ `</form>`;
		modalize('Change Password', template_html);
		
		var $form = $('.changepassword');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/reseller/change_password.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-changepass").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listreseller').DataTable().ajax.reload();
    				$(".changepassword").trigger("reset")
    				$("#btn-changepass").removeClass("btn-progress");
        		}
        	});
	})
	
	//Block Reseller
    $(".modalize").on("click", ".btn-modal-blockreseller", function(e)
	{
		var userid = $(this).data("id");
		$.ajax({
            url: "{$base_url}serverside/data/get_userinfo.php",
            data: "uid="+userid,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			var template_html = `<form class="blockreseller" method="post" autocomplete="off">`
        							+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
        							+ `<input type="hidden" name="id" value="`+userid+`">`
        							+ `<input type="hidden" name="submitted" value="block_user">`
        							+ `<div class="form-group"><label for="isblock">Status</label><input id="isblock" value="`+data.blockstatus+`" class="form-control" type="text" readonly></div>`
        							+ `<div class="form-group"><label for="goblock">Action</label>`
        							+ `<select class="form-control" name="confirmblock">`
        							+ `<option value="doblock">Block</option>`
        							+ `<option value="dounblock">Unblock</option>`
        							+ `</select>`
        							+ `</div>`
        							+ `<div class="form-group"><button type="submit" class="btn btn-primary btn-lg btn-block btn-blockreseller" id="btn-blockreseller" tabindex="4">Confirm</button></div>`
        							+ `</form>`;
        		modalize('Block Reseller', template_html);
        		
        		var $form = $('.blockreseller');
                	$form.ajaxForm({
                		type: "POST",
                		url: "{$base_url}serverside/forms/reseller/block_reseller.php",
                		data: $form.serialize(),
                		dataType: "JSON",
        		        cache: false,
                		beforeSend: function() {
                			$("#btn-blockreseller").addClass("btn-progress");
                		},
                		success: function(data){
                			if(data.response == 1){
            					errorMessage('success', 'Success', data.msg);
            				}
            				if(data.response == 2){
            					errorMessage('danger','Error', data.msg);
            				}
            				if(data.response == 3){
            					errorMessage('danger','Error', data.errormsg);
            				}
                		},
                		error: function(jqXHR, textStatus, errorThrown) {
                			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                                button: false,
                                closeOnClickOutside: false,
                                timer: 3000
                            }).then(() => {
                                location.reload()
                            });
                		},
                		complete: function(){
                			$('.table-listreseller').DataTable().ajax.reload();
            				$(".blockreseller").remove();
            				$("#btn-blockreseller").removeClass("btn-progress");
                		}
                	});
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
    
    		}
        });
	})
    
    //Reseller Delete
    $(".modalize").on("click", ".btn-modal-deletereseller", function(e)
	{
		var userid = $(this).data("id");
		var username = $(this).data("username");

		var template_html = `<form class="deletereseller" autocomplete="off">`
                        		+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                        		+ `<input type="hidden" name="id" value="`+userid+`">`
                        		+ `<input type="hidden" name="submitted" value="delete_user">`
                        		+ `<div class="form-group"><label for="username">Username</label><input id="username" class="form-control" type="text" value="`+username+`" readonly></div>`
                        		+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-deletereseller" id="btn-deletereseller" tabindex="4">Confirm</button></div>`
                        		+ `</form>`;
		modalize('Delete', template_html);
		
		var $form = $('.deletereseller');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/reseller/delete_reseller.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-deletereseller").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listreseller').DataTable().ajax.reload();
    				$(".deletereseller").remove();
    				$("#btn-deletereseller").removeClass("btn-progress");
        		}
        	});
	})
	function getD(){
        $.ajax({
            url: "{$base_url}serverside/data/get_data.php",
            type: "GET",
            dataType: "JSON",
        	cache: false,
            success: function(data)
            {
        		if(data.response == 1){
       
                }
                if(data.response == 2){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
                if(data.response == 3){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Error`, `Error parsing data.`, `error`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
        
        	}
        });
    }
    getD()
});
</script>