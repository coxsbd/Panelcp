<script>
function modalize(title, body)
	{
	    $(".modalize").modal({
            backdrop: 'static',
            keyboard: false  // to prevent closing with Esc button (if you want this too)
        })
        $(".modalize").modal('show');
		$(".modal-title").text(title);
		$(".modal-error").html('');
		$(".modal-html").html(body);
	}

function errorMessage(type,title,message)
	{
		$(".modal-body > .modal-error").html('').append('<div class="alert alert-'+type+' alert-has-icon"><div class="alert-icon"><i class="far fa-lightbulb"></i></div><div class="alert-body"><div class="alert-title">'+title+'</div>'+message+'</div></div>').slideDown();
	}

function view_info(u) {
	$.ajax({
        url: "{$base_url}serverside/data/get_userinfo.php",
        data: "uid="+u,
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
            var template_html =  `<div class="form-group"><label for="username">Username</label><input class="form-control" id="username" type="text" value="`+data.username+`" readonly><div>
				<div class="form-group"><label for="password">Password</label><input class="form-control" id="password" type="text" value="`+data.userpass+`" readonly><div>
				<div class="form-group"><label for="subscription">Subscription</label><input class="form-control" id="subscription" type="text" value="`+data.subscription+`" readonly><div>
				<div class="form-group"><label for="expiration">Expiration</label><input class="form-control" id="expiration" type="text" value="`+data.expired+`" readonly><div>
				<div class="form-group"><label for="upline">Upline</label><input class="form-control" id="upline" type="text" value="`+data.upline+`" readonly><div>
				<div class="form-group"><label for="device">Device</label><input class="form-control" id="device" type="text" value="`+data.device+`" readonly><div>`;
			modalize('Details', template_html);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
}

function user_option(u) {
	$.ajax({
        url: "{$base_url}serverside/data/get_useroption.php",
        data: "uid="+u,
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
			var template_html = `<div class="form-group">
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-changepassword" tabindex="4" data-id="`+u+`">Change Password</button>
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-blockuser" tabindex="4" data-id="`+u+`">Block User</button>
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-sessionreset" tabindex="4" data-id="`+u+`" data-username="`+data.username+`">Session Reset</button>
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-devicereset" tabindex="4" data-id="`+u+`" data-username="`+data.username+`">Device Reset</button>
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-extendduration" tabindex="4" data-id="`+u+`">Extend Duration</button>
                                	<button type="submit" class="btn btn-primary btn-lg btn-block btn-modal-socksip" tabindex="4" data-id="`+u+`" data-username="`+data.username+`">Activate SocksIP</button>
                                	<button type="submit" class="btn btn-danger btn-lg btn-block btn-modal-deleteuser" tabindex="4" data-id="`+u+`" data-username="`+data.username+`">Delete User</button>
                                </div>`;
			modalize('Actions', template_html);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
}
	
$('document').ready(function()
{
    function normalTable() {
        $.fn.dataTable.ext.errMode = () => swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
            button: false,
            closeOnClickOutside: false,
            timer: 3000
        }).then(() => {
            location.reload()
        });
    	$('.table-listuser').dataTable({
    	    responsive: true,
            "bProcessing": false,
            "bServerSide": true,
            "ajax": {
                "url": "/normal-serverside",
                "type": "POST"
            },
            order: [[ 0, 'desc' ], [ 0, 'asc' ]],
            "language": {                
                "infoFiltered": ""
            },
            columnDefs: [
                {
                  width: '11%',
                  targets: 0,
                },
                {
                  width: '11%',
                  targets: 1,
                },
                {
                  width: '11%',
                  targets: 2,
                },
                {
                  width: '11%',
                  targets: 3,
                },
                {
                  width: '11%',
                  targets: 4,
                },
                {
                  width: '5%',
                  targets: 5,
                },
                {
                  orderable: false,
                  targets: [1, 2, 3, 4, 5],
                },
            ],
    	});
    }
    
    function bulkTable() {
        $.fn.dataTable.ext.errMode = () => swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
            button: false,
            closeOnClickOutside: false,
            timer: 3000
        }).then(() => {
            location.reload()
        });
    	$('.table-listuser').dataTable({
    	    responsive: true,
            "bProcessing": false,
            "bServerSide": true,
            "ajax": {
                "url": "/bulk-serverside",
                "type": "POST"
            },
            order: [[ 0, 'desc' ], [ 0, 'asc' ]],
            "language": {                
                "infoFiltered": ""
            },
            columnDefs: [
            {
              width: '11%',
              targets: 0,
            },
            {
              width: '11%',
              targets: 1,
            },
            {
              width: '11%',
              targets: 2,
            },
            {
              width: '11%',
              targets: 3,
            },
            {
              width: '11%',
              targets: 4,
            },
            {
              width: '5%',
              targets: 5,
            },
            {
              orderable: false,
              targets: [1, 2, 3, 4, 5],
            },
          ],
    	});
    }
    
    function inactiveTable() {
        $.fn.dataTable.ext.errMode = () => swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
            button: false,
            closeOnClickOutside: false,
            timer: 3000
        }).then(() => {
            location.reload()
        });
    	$('.table-listuser').dataTable({
    	    responsive: true,
            "bProcessing": false,
            "bServerSide": true,
            "ajax": {
                "url": "/inactive-serverside",
                "type": "POST"
            },
            order: [[ 0, 'desc' ], [ 0, 'asc' ]],
            "language": {                
                "infoFiltered": ""
            },
            columnDefs: [
            {
              width: '11%',
              targets: 0,
            },
            {
              width: '11%',
              targets: 1,
            },
            {
              width: '11%',
              targets: 2,
            },
            {
              width: '11%',
              targets: 3,
            },
            {
              width: '11%',
              targets: 4,
            },
            {
              width: '5%',
              targets: 5,
            },
            {
              orderable: false,
              targets: [1, 2, 3, 4, 5],
            },
          ],
    	});
    }
    
    function trialTable() {
        $.fn.dataTable.ext.errMode = () => swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
            button: false,
            closeOnClickOutside: false,
            timer: 3000
        }).then(() => {
            location.reload()
        });
    	$('.table-listuser').dataTable({
    	    responsive: true,
            "bProcessing": false,
            "bServerSide": true,
            "ajax": {
                "url": "/trial-serverside",
                "type": "POST"
            },
            "language": {                
                "infoFiltered": ""
            },
            columnDefs: [
            {
              width: '11%',
              targets: 0,
            },
            {
              width: '11%',
              targets: 1,
            },
            {
              width: '11%',
              targets: 2,
            },
            {
              width: '11%',
              targets: 3,
            },
            {
              width: '11%',
              targets: 4,
            },
            {
              width: '5%',
              targets: 5,
            },
            {
              orderable: false,
              targets: [1, 2, 3, 4, 5],
            },
          ],
    	});
    }
    
    function reinitializeTable() {
        if ($.fn.DataTable.isDataTable('.table-listuser')) {
          $('.table-listuser').DataTable().clear().destroy();
        }
    }
    
    function getActive(u) {
		$.ajax({
        url: "{$base_url}serverside/data/get_active.php",
        data: "type="+u,
        type: "GET",
        dataType: "JSON",
		cache: false,
        success: function(data)
        {
			$('.Active').val(data.active);
			$('.Inactive').val(data.inactive);
			$('.Total').val(data.total);
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
        },
        complete: function(){

		}
    });
	}
    
    getActive('normal')
    normalTable()
    
    $('#tabletype').on('change', function () {
        var curTable = $("#tabletype option:selected").text();
        
        if(curTable === "Trial")
		{
			$('#ActiveCounter').addClass("d-none")
			$('.currentloaded').val(curTable +' Users')
			reinitializeTable()
			trialTable()
		}else if(curTable === "Bulk")
		{
			$('#ActiveCounter').removeClass("d-none")
			$('.currentloaded').val(curTable +' Users')
			getActive($("#tabletype option:selected").val());
			reinitializeTable()
			bulkTable()
		}else if(curTable === "Inactive")
		{
			$('#ActiveCounter').removeClass("d-none")
			$('.currentloaded').val(curTable +' Users')
			getActive($("#tabletype option:selected").val());
			reinitializeTable()
			inactiveTable()
		}else if(curTable === "Normal")
		{
			$('#ActiveCounter').removeClass("d-none")
			$('.currentloaded').val(curTable +' Users')
			getActive($("#tabletype option:selected").val());
			reinitializeTable()
			normalTable()
		}
    });
    
    
    //Change Password
    $(".modalize").on("click", ".btn-modal-changepassword", function(e)
	{
		var userid = $(this).data("id");

		var template_html = `<form class="changepassword" method="post" autocomplete="off">`
						+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
						+ `<input type="hidden" name="id" value="`+userid+`">`
						+ `<input type="hidden" name="submitted" value="change_password">`
						+ `<div class="form-group"><label for="newpassword">New Password</label><input id="newpassword" class="form-control" name="newpassword" type="text"></div>`
						+ `<div class="form-group"><button type="submit" class="btn btn-primary btn-lg btn-block btn-changepass" id="btn-changepass" tabindex="4">Change</button></div>`
						+ `</form>`;
		modalize('Change Password', template_html);
		
		var $form = $('.changepassword');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/user/change_password.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-changepass").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
    				$(".changepassword").trigger("reset")
    				$("#btn-changepass").removeClass("btn-progress");
        		}
        	});
	})
	
	
	//Block User
    $(".modalize").on("click", ".btn-modal-blockuser", function(e)
	{
		var userid = $(this).data("id");
		$.ajax({
            url: "{$base_url}serverside/data/get_userinfo.php",
            data: "uid="+userid,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			var template_html = `<form class="blockuser" method="post" autocomplete="off">`
        							+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
        							+ `<input type="hidden" name="id" value="`+userid+`">`
        							+ `<input type="hidden" name="submitted" value="block_user">`
        							+ `<div class="form-group"><label for="isblock">Status</label><input id="isblock" value="`+data.blockstatus+`" class="form-control" type="text" readonly></div>`
        							+ `<div class="form-group"><label for="goblock">Action</label>`
        							+ `<select class="form-control" name="confirmblock">`
        							+ `<option value="doblock">Block</option>`
        							+ `<option value="dounblock">Unblock</option>`
        							+ `</select>`
        							+ `</div>`
        							+ `<div class="form-group"><button type="submit" class="btn btn-primary btn-lg btn-block btn-blockuser" id="btn-blockuser" tabindex="4">Confirm</button></div>`
        							+ `</form>`;
        		modalize('Block User', template_html);
        		
        		var $form = $('.blockuser');
                	$form.ajaxForm({
                		type: "POST",
                		url: "{$base_url}serverside/forms/user/block_user.php",
                		data: $form.serialize(),
                		dataType: "JSON",
        		        cache: false,
                		beforeSend: function() {
                			$("#btn-blockuser").addClass("btn-progress");
                		},
                		success: function(data){
                			if(data.response == 1){
            					errorMessage('success', 'Success', data.msg);
            				}
            				if(data.response == 2){
            					errorMessage('danger','Error', data.msg);
            				}
            				if(data.response == 3){
            					errorMessage('danger','Error', data.errormsg);
            				}
                		},
                		error: function(jqXHR, textStatus, errorThrown) {
                			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                                button: false,
                                closeOnClickOutside: false,
                                timer: 3000
                            }).then(() => {
                                location.reload()
                            });
                		},
                		complete: function(){
                			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
            				$(".blockuser").remove();
            				$("#btn-blockuser").removeClass("btn-progress");
                		}
                	});
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
    
    		}
        });
	})
	
	//SocksIP
    $(".modalize").on("click", ".btn-modal-socksip", function(e)
	{
		var userid = $(this).data("id");
		var username = $(this).data("username");
		$.ajax({
            url: "{$base_url}serverside/data/get_userinfo.php",
            data: "uid="+userid,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			var template_html = `<form class="socksip" autocomplete="off">`
                                		+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                                		+ `<input type="hidden" name="id" value="`+userid+`">`
                                		+ `<input type="hidden" name="submitted" value="add_socksip">`
                                		+ `<p class="text-center">Do you want to enable <code>`+username+`'s</code> socksip access ?</p>`
                                		+ `<p class="text-center">This will activate <code>`+username+`'s</code> account status</p>`
                                		+ `<p class="text-center">Note: Numeric username will not be allowed to use this service.</p>`
                                		+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-socksip" id="btn-socksip" tabindex="4">Confirm</button></div>`
                                		+ `</form>`;
        		modalize('Activate SocksIP', template_html);
        		
        		var $form = $('.socksip');
                	$form.ajaxForm({
                		type: "POST",
                		url: "{$base_url}serverside/forms/user/socksip.php",
                		data: $form.serialize(),
                		dataType: "JSON",
        		        cache: false,
                		beforeSend: function() {
                			$("#btn-socksip").addClass("btn-progress");
                		},
                		success: function(data){
                			if(data.response == 1){
            					errorMessage('success', 'Success', data.msg);
            				}
            				if(data.response == 2){
            					errorMessage('danger','Error', data.msg);
            				}
            				if(data.response == 3){
            					errorMessage('danger','Error', data.errormsg);
            				}
                		},
                		error: function(jqXHR, textStatus, errorThrown) {
                			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                                button: false,
                                closeOnClickOutside: false,
                                timer: 3000
                            }).then(() => {
                                location.reload()
                            });
                		},
                		complete: function(){
                			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
            				$(".socksip").remove();
            				$("#btn-socksip").removeClass("btn-progress");
                		}
                	});
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
    
    		}
        });
	})
	
	//Session Reset
    $(".modalize").on("click", ".btn-modal-sessionreset", function(e)
	{
		var userid = $(this).data("id");
		var username = $(this).data("username");

		var template_html = `<form class="sessionreset" autocomplete="off">`
                        		+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                        		+ `<input type="hidden" name="id" value="`+userid+`">`
                        		+ `<input type="hidden" name="submitted" value="session_reset">`
                        		+ `<p class="text-center">Proceed resetting <code>`+username+`'s</code> vpn session ?</p>`
                        		+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-session" id="btn-session" tabindex="4">Confirm</button></div>`
                        		+ `</form>`;
		modalize('Session Reset', template_html);
		
		var $form = $('.sessionreset');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/user/session_reset.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-session").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
    				$(".sessionreset").remove();
    				$("#btn-session").removeClass("btn-progress");
        		}
        	});
	})
	
	//Device Reset
    $(".modalize").on("click", ".btn-modal-devicereset", function(e)
	{
		var userid = $(this).data("id");
		var username = $(this).data("username");

		var template_html = `<form class="devicereset" autocomplete="off">`
                        		+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                        		+ `<input type="hidden" name="id" value="`+userid+`">`
                        		+ `<input type="hidden" name="submitted" value="device_reset">`
                        		+ `<p class="text-center">Proceed resetting <code>`+username+`'s</code> device ?</p>`
                        		+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-device" id="btn-device" tabindex="4">Confirm</button></div>`
                        		+ `</form>`;
		modalize('Device Reset', template_html);
		
		var $form = $('.devicereset');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/user/device_reset.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-device").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
    				$(".devicereset").remove();
    				$("#btn-device").removeClass("btn-progress");
        		}
        	});
	})
	
	//Extend User
    $(".modalize").on("click", ".btn-modal-extendduration", function(e)
	{
		var userid = $(this).data("id");
		var template_html
		
		$.ajax({
            url: "{$base_url}serverside/data/get_userinfo.php",
            data: "uid="+userid,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			if(data.expired == 'none')
    			{
    				template_html = `<p class="text-center">User <code>`+data.username+`</code> is not activated.</p>`
    			}else{
    				template_html = `<form class="extendduration" autocomplete="off">`
    					+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                        + `<input type="hidden" name="id" value="`+userid+`">`
                        + `<input type="hidden" name="submitted" value="extend_user">`
    					+ `<p><code>Note :</code> You must have enough remaining credit to extend a duration.</p>`
    					+ `<div class="form-group"><label for="username">Username</label><input class="form-control" type="text" value="`+data.username+`" readonly><div>`
    					+ `<div class="form-group"><label for="expiration">Expiration</label><input class="form-control" type="text" value="`+data.expired+`" readonly><div>`
    					+ `<div class="form-group"><label for="duration">Duration</label><select class="form-control" id="duration" name="duration">`
    					+ `<option value="1m">1 Month</option>`
    					+ `<option value="2m">2 Months</option>`
    					+ `<option value="3m">3 Months</option>`
    					+ `<option value="4m">4 Months</option>`
    					+ `<option value="5m">5 Months</option>`
    					+ `</select></div>`
    					+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-extend" id="btn-extend" tabindex="4">Confirm</button></div>`
    					+ `</form>`;
    				}
    			modalize('Extend', template_html);
        		
        		var $form = $('.extendduration');
                	$form.ajaxForm({
                		type: "POST",
                		url: "{$base_url}serverside/forms/user/extend_user.php",
                		data: $form.serialize(),
                		dataType: "JSON",
        		        cache: false,
                		beforeSend: function() {
                			$("#btn-extend").addClass("btn-progress");
                		},
                		success: function(data){
                			if(data.response == 1){
            					errorMessage('success', 'Success', data.msg);
            				}
            				if(data.response == 2){
            					errorMessage('danger','Error', data.msg);
            				}
            				if(data.response == 3){
            					errorMessage('danger','Error', data.errormsg);
            				}
                		},
                		error: function(jqXHR, textStatus, errorThrown) {
                			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                                button: false,
                                closeOnClickOutside: false,
                                timer: 3000
                            }).then(() => {
                                location.reload()
                            });
                		},
                		complete: function(){
                			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
            				$(".extendduration").remove();
            				$("#btn-extend").removeClass("btn-progress");
                		}
                	});
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
    
    		}
        });
	})
	
	//User Delete
    $(".modalize").on("click", ".btn-modal-deleteuser", function(e)
	{
		var userid = $(this).data("id");
		var username = $(this).data("username");

		var template_html = `<form class="deleteuser" autocomplete="off">`
                        		+ `<input type="hidden" name="_key" value="{$firenet_encrypt}">`
                        		+ `<input type="hidden" name="id" value="`+userid+`">`
                        		+ `<input type="hidden" name="submitted" value="delete_user">`
                        		+ `<div class="form-group"><label for="username">Username</label><input id="username" class="form-control" type="text" value="`+username+`" readonly></div>`
                        		+ `<div class="form-group"><button type="submit" class="btn btn-danger btn-lg btn-block btn-deleteuser" id="btn-deleteuser" tabindex="4">Confirm</button></div>`
                        		+ `</form>`;
		modalize('Delete', template_html);
		
		var $form = $('.deleteuser');
        	$form.ajaxForm({
        		type: "POST",
        		url: "{$base_url}serverside/forms/user/delete_user.php",
        		data: $form.serialize(),
        		dataType: "JSON",
		        cache: false,
        		beforeSend: function() {
        			$("#btn-deleteuser").addClass("btn-progress");
        		},
        		success: function(data){
        			if(data.response == 1){
    					errorMessage('success', 'Success', data.msg);
    				}
    				if(data.response == 2){
    					errorMessage('danger','Error', data.msg);
    				}
    				if(data.response == 3){
    					errorMessage('danger','Error', data.errormsg);
    				}
        		},
        		error: function(jqXHR, textStatus, errorThrown) {
        			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
        		},
        		complete: function(){
        			$('.table-listuser').DataTable().ajax.reload( getActive($("#tabletype option:selected").val()), false );
    				$(".deleteuser").remove();
    				$("#btn-deleteuser").removeClass("btn-progress");
        		}
        	});
	})
	function getD(){
        $.ajax({
            url: "{$base_url}serverside/data/get_data.php",
            type: "GET",
            dataType: "JSON",
        	cache: false,
            success: function(data)
            {
        		if(data.response == 1){
       
                }
                if(data.response == 2){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
                if(data.response == 3){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Error`, `Error parsing data.`, `error`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            },
            complete: function(){
        
        	}
        });
    }
    getD()
});
</script>