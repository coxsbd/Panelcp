<script>
$('document').ready(function()
{
    function modalize(title, body) {
        $(".modalize").modal({
            backdrop: "static"
        });
        $(".modal-title").html(title);
        $(".modal-html").html(body);
    }

    function getDashboard(){
    	$.ajax({
            url: "{$base_url}serverside/data/get_dashboard.php",
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			if(data.response == 1)
    			{
    				$('.stats-reseller').text(data.reseller);
    				$('.stats-user').text(data.user);
    				$('.stats-online').text(data.online);
    				$('.stats-server').text(data.servercount);
    				$('.profile-username').text(data.profile_username);
    				$('.profile-upline').text(data.profile_upline);
    				$('.profile-credits').text(data.profile_credits);
    				$('.table-activity').append(data.activity);
    				$(".profile-servers").html(data.servers.length ? data.servers.join('') : '<li class="list-group-item text-muted">No servers found.</li>');

    				// Badge counts for user breakdown card
    				$('.stats-trial-count').text(data.trial || 0);
    				$('.stats-normal-count').text(data.normal || 0);
    				$('.stats-bulk-count').text(data.bulk || 0);

    				// Second doughnut chart (user breakdown card)
    				if(typeof Chart !== 'undefined' && $('#userchart2').length){
    				var myChart2 = new Chart($("#userchart2"), {
                        type: 'doughnut',
                        data: {
                            datasets: [{
                                data: [data.trial, data.normal, data.bulk],
                                backgroundColor: ['#fc544b', '#63ed7a', '#6777ef'],
                            }],
                            labels: ['Trial', 'Normal', 'Bulk'],
                        },
                        options: {
                            responsive: true,
                            legend: { position: 'bottom' },
                        }
                    });
    				}
    				$('.panel-duration').text(data.licdur);

    				// Show remaining days for normal/bulk/trial users
    				if(data.user_duration){
    					$('.user-account-duration').text(data.user_duration);
    				}

    				if(typeof Chart !== 'undefined' && $('#userchart').length){
    				var myChart = new Chart($("#userchart"), {
                        type: 'doughnut',
                        data: {
                            datasets: [{
                                data: [data.trial, data.normal, data.bulk],
                                backgroundColor: ['#fc544b', '#63ed7a', '#6777ef'],
                                label: 'Dataset 1'
                            }],
                            labels: ['Trial', 'Normal', 'Bulk'],
                        },
                        options: {
                            responsive: true,
                            legend: {
                                position: 'bottom',
                            },
                        }
                    });
    				}
    			}
    			// Silently ignore response 2/0 — don't reload, don't popup
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                // Silently ignore AJAX errors on dashboard load — don't reload
                console.log('getDashboard error: ' + textStatus);
            }
        });
    }

    function getNotification(){
        $.ajax({
            url: "{$base_url}serverside/data/get_notification.php",
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
                var notifications = '';
    			if(data.response == 1)
    			{
    			    if (data.notiftotal === 0) {
    			        $(".notification-toggle").removeClass("beep");
    				    notifications = `<a href="javascript:void(0)" class="dropdown-item dropdown-item-unread">
                                        	<div class="dropdown-item-icon bg-primary text-white">
                                        		<i class="far fa-smile"></i>
                                        	</div>
                                        	<div class="dropdown-item-desc"> No available notifications to show for now. <div class="time text-primary">Stay safe and secure.</div>
                                        	</div>
                                        </a>`;
    			    }else{
    			        $(".notification-toggle").addClass("beep");
    			        notifications = data.notifica;
    			    }
    			    $(".profile-notifications").html(notifications);
    			}
    			// Silently ignore errors — don't reload
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                console.log('getNotification error: ' + textStatus);
            }
        });
    }

    $(".notificationlist").on("click", ".view-notification", function() {
        var id = $(this).data("id");
        var type = $(this).data("type");
        var date = $(this).data("date");

        $.ajax({
            url: "{$base_url}serverside/data/read_notification.php",
            data: "id="+id,
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			if(data.response == 1){
            		modalize(`<span class="badge badge-primary">`+type+`</span> Posted `+date+` `, data.content);
            	}
            	if(data.response == 2){
            		modalMessage('danger','Error', data.msg);
            	}
            	if(data.response == 3){
            		modalMessage('danger','Error', data.errormsg);
            	}
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                console.log('read_notification error: ' + textStatus);
            },
            complete: function(){
    		}
        });

    })

    function getVersion(){
        $.ajax({
            url: "{$base_url}serverside/data/get_version.php",
            type: "GET",
            dataType: "JSON",
        	cache: false,
            success: function(data)
            {
        		if(data.response == 1){
                	if (data.length > 0) {
                        $('.fetch-update').show().addClass('show')
                        $('.fetch-duration').show().addClass('show')
            		    $('.panel-version').text(data.version);
                    	$('.panel-update-list').append(data.content);
                    }
                    if (data.length < 1){
                        $('.fetch-update').show().addClass('d-none')
                        $('.fetch-duration').show().addClass('show')
                    }
                    {if $user_id_2 == 1 || $user_level_2 == 'superadmin' || $user_level_2 == 'developer'}
                    if (data.versiontitle) {
                        var htmlContent = document.createElement("div");
                            htmlContent.innerHTML = data.versionmsg;
                        swal({
                            title: data.versiontitle,
                            content: htmlContent,
                            icon: data.versiontype,
                            closeOnClickOutside: false,
                            button: true
                        })
                    }
                    {/if}
                }
                // Silently ignore version check errors — don't reload
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                console.log('getVersion error: ' + textStatus);
            },
            complete: function(){
        	}
        });
    }

    function getF(){
        $.ajax({
            url: "{$base_url}serverside/data/get_data.php",
            type: "GET",
            dataType: "JSON",
        	cache: false,
            success: function(data)
            {
        		if(data.response == 1){
        		    getVersion();
                }
                if(data.response == 2 && data.licmsg){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
                if(data.response == 3 && data.licmsg){
                	swal(`Error`, data.licmsg, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 5000
                    }).then(() => {
                        location.reload()
                    });
                }
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                console.log('getF error: ' + textStatus);
            },
            complete: function(){
        	}
        });
    }

getF();
getDashboard();
getNotification();
});
</script>
