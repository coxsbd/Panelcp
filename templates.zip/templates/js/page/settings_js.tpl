<script>
    function reloadPage()
    {
    	setTimeout(function(){
    		location.reload();
    	}, 3000)
    }
    
    function getSettings()
    {
    	$.ajax({
            url: "{$base_url}serverside/data/get_settings.php",
            type: "GET",
            dataType: "JSON",
    		cache: false,
            success: function(data)
            {
    			if(data.response == 1)
    			{
    				$('.logoshow').html(data.logoshow);
    				$('.logoshow').val(data.logoshow_);
    				$('.maintenance').html(data.maintenance);
    				$('.maintenance').val(data.maintenance_);
    				$('.theme').html(data.theme);
    				$('.theme').val(data.theme_);
    				$('#title').val(data.name);
    				$('#description').val(data.description);
    				$('#owner').val(data.owner);
    				$('#logo').val(data.logo);
    				$(".trialcounter").val(data.trialuser);
    				$(".sessions").val(data.sessions);
    				
    				$(".download1_name").val(data.download1_name);
    				$(".download1_url").val(data.download1_url);
    				$(".download2_name").val(data.download2_name);
    				$(".download2_url").val(data.download2_url);
    				$(".download3_name").val(data.download3_name);
    				$(".download3_url").val(data.download3_url);
    				
    				if($(".download1_name").val() == ''){
    				    $(".download2").addClass('d-none');
    				}else{
    				    $(".download2").removeClass('d-none');
    				}
    				
    				if($(".download2_name").val() == ''){
    				    $(".download3").addClass('d-none');
    				}else{
    				    $(".download3").removeClass('d-none');
    				}
    				
    				$(".summernote").summernote("code", data.note);
    				
    				var $firenet5 = $('.prefix').html(data.prefixz);
    				var $firenet6 = $('.prefix').val(data.prefixz_);
                    $('#uprefix').val(data.uprefix);
                    
                    var $firenet7 = $('.trialdur').html(data.trialdura);
    				var $firenet8 = $('.trialdur').val(data.trialdura_);
    			}
    			if(data.response == 2)
    			{
    				swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
    			}
    			if(data.response == 0){
    				swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
    			}
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
            }
        });
    }
    	
    $('document').ready(function()
    {
        getSettings()
        
        //Web Settings
        $("#websettings > .btn-confirm-web").click(function(){
            $("#websettings > .btn-confirm-cancel").removeClass("d-none")
            $("#websettings > .btn-confirm-web").addClass("d-none")
            $("#websettings > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#websettings > .btn-confirm-cancel").click(function(){
            $("#websettings > .btn-confirm-cancel").addClass("d-none")
            $("#websettings > .btn-confirm-web").removeClass("d-none")
            $("#websettings > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.websettings');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/web_settings.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#websettings > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#websettings > .btn-confirm-auth").removeClass("btn-progress")
    			$("#websettings > .btn-confirm-web").removeClass("d-none")
    			$("#websettings > .btn-confirm-auth").addClass("d-none")
    			$("#websettings > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//Trial Reset
    	$("#trialsettings > .btn-confirm-trial").click(function(){
            $("#trialsettings > .btn-confirm-cancel").removeClass("d-none")
            $("#trialsettings > .btn-confirm-trial").addClass("d-none")
            $("#trialsettings > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#trialsettings > .btn-confirm-cancel").click(function(){
            $("#trialsettings > .btn-confirm-cancel").addClass("d-none")
            $("#trialsettings > .btn-confirm-trial").removeClass("d-none")
            $("#trialsettings > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.trialsettings');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/trial_reset.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#trialsettings > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      closeOnClickOutside: false
                    });
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#trialsettings > .btn-confirm-auth").removeClass("btn-progress")
    			$("#trialsettings > .btn-confirm-trial").removeClass("d-none")
    			$("#trialsettings > .btn-confirm-auth").addClass("d-none")
    			$("#trialsettings > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//VPN Session
    	$("#vpnsettings > .btn-confirm-session").click(function(){
            $("#vpnsettings > .btn-confirm-cancel").removeClass("d-none")
            $("#vpnsettings > .btn-confirm-session").addClass("d-none")
            $("#vpnsettings > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#vpnsettings > .btn-confirm-cancel").click(function(){
            $("#vpnsettings > .btn-confirm-cancel").addClass("d-none")
            $("#vpnsettings > .btn-confirm-session").removeClass("d-none")
            $("#vpnsettings > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.vpnsettings');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/vpn_session.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#vpnsettings > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      closeOnClickOutside: false
                    });
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#vpnsettings > .btn-confirm-auth").removeClass("btn-progress")
    			$("#vpnsettings > .btn-confirm-session").removeClass("d-none")
    			$("#vpnsettings > .btn-confirm-auth").addClass("d-none")
    			$("#vpnsettings > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//App Update
    	$("#downloadsettings > .btn-confirm-app").click(function(){
            $("#downloadsettings > .btn-confirm-cancel").removeClass("d-none")
            $("#downloadsettings > .btn-confirm-app").addClass("d-none")
            $("#downloadsettings > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#downloadsettings > .btn-confirm-cancel").click(function(){
            $("#downloadsettings > .btn-confirm-cancel").addClass("d-none")
            $("#downloadsettings > .btn-confirm-app").removeClass("d-none")
            $("#downloadsettings > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.downloadsettings');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/app_update.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#downloadsettings > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      closeOnClickOutside: false
                    });
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#downloadsettings > .btn-confirm-auth").removeClass("btn-progress")
    			$("#downloadsettings > .btn-confirm-app").removeClass("d-none")
    			$("#downloadsettings > .btn-confirm-auth").addClass("d-none")
    			$("#downloadsettings > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//User Settings
    	$("#usersettings > .btn-confirm-user").click(function(){
            $("#usersettings > .btn-confirm-cancel").removeClass("d-none")
            $("#usersettings > .btn-confirm-user").addClass("d-none")
            $("#usersettings > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#usersettings > .btn-confirm-cancel").click(function(){
            $("#usersettings > .btn-confirm-cancel").addClass("d-none")
            $("#usersettings > .btn-confirm-user").removeClass("d-none")
            $("#usersettings > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.usersettings');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/user_settings.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#usersettings > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      closeOnClickOutside: false
                    });
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#usersettings > .btn-confirm-auth").removeClass("btn-progress")
    			$("#usersettings > .btn-confirm-user").removeClass("d-none")
    			$("#usersettings > .btn-confirm-auth").addClass("d-none")
    			$("#usersettings > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//Clear Device
        $("#deletedevice > .btn-confirm-clrdevice").click(function(){
            $("#deletedevice > .btn-confirm-cancel").removeClass("d-none")
            $("#deletedevice > .btn-confirm-clrdevice").addClass("d-none")
            $("#deletedevice > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#deletedevice > .btn-confirm-cancel").click(function(){
            $("#deletedevice > .btn-confirm-cancel").addClass("d-none")
            $("#deletedevice > .btn-confirm-clrdevice").removeClass("d-none")
            $("#deletedevice > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.clrdevice');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/device_reset.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#deletedata > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#deletedata > .btn-confirm-auth").removeClass("btn-progress")
    			$("#deletedata > .btn-confirm-clrdevice").removeClass("d-none")
    			$("#deletedata > .btn-confirm-auth").addClass("d-none")
    			$("#deletedata > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	//Delete Expired
        $("#delete_xpired > .btn-confirm-delxpired").click(function(){
            $("#delete_xpired > .btn-confirm-cancel").removeClass("d-none")
            $("#delete_xpired > .btn-confirm-delxpired").addClass("d-none")
            $("#delete_xpired > .btn-confirm-auth").removeClass("d-none")
        });
        
        $("#delete_xpired > .btn-confirm-cancel").click(function(){
            $("#delete_xpired > .btn-confirm-cancel").addClass("d-none")
            $("#delete_xpired > .btn-confirm-delxpired").removeClass("d-none")
            $("#delete_xpired > .btn-confirm-auth").addClass("d-none")
        });
        
        var $form = $('.deletexpired');
    	$form.ajaxForm({
    		type: "POST",
    		url: "{$base_url}serverside/forms/delete_expired.php",
    		data: $form.serialize(),
    		dataType: "JSON",
    		cache: false,
    		beforeSend: function() {
    			$("#delete_xpired > .btn-confirm-auth").addClass("btn-progress")
    		},
    		success: function(data){
    		    if(data.response == 1){
        			swal(`Success!`, data.msg, `success`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 2){
        			swal(`Ooops!`, data.msg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
        		if(data.response == 3){
        			swal(`Ohh no!`, data.errormsg, `error`, {
                      button: false,
                      closeOnClickOutside: false
                    });
                    reloadPage();
        		}
    		},
    		error: function(jqXHR, textStatus, errorThrown) {
    			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                    button: false,
                    closeOnClickOutside: false,
                    timer: 3000
                }).then(() => {
                    location.reload()
                });
    		},
    		complete: function(){
    			$("#delete_xpired > .btn-confirm-auth").removeClass("btn-progress")
    			$("#delete_xpired > .btn-confirm-delxpired").removeClass("d-none")
    			$("#delete_xpired > .btn-confirm-auth").addClass("d-none")
    			$("#delete_xpired > .btn-confirm-cancel").addClass("d-none")
    		}
    	});
    	
    	$('.download1_name').on('input', function() {
            if($(".download1_name").val() == ''){
        	    $(".download2").addClass('d-none')
        	}else{
        	    $(".download2").removeClass('d-none')
        	}
        });
    	
    	$('.download2_name').on('input', function() {
            if($(".download2_name").val() == ''){
        	    $(".download3").addClass('d-none')
        	}else{
        	    $(".download3").removeClass('d-none')
        	}
        });
    	
    	$(document).on('click', '.upload-field', function(){
            var file = $(this).parent().parent().parent().find('.input-file');
            file.trigger('click');
        });

        $(document).on('change', '.input-file', function(){
            $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
        });
    	
    	function getD(){
            $.ajax({
                url: "{$base_url}serverside/data/get_data.php",
                type: "GET",
                dataType: "JSON",
            	cache: false,
                success: function(data)
                {
            		if(data.response == 1){
           
                    }
                    if(data.response == 2){
                    	swal(`Error`, data.licmsg, `error`, {
                            button: false,
                            closeOnClickOutside: false,
                            timer: 5000
                        }).then(() => {
                            location.reload()
                        });
                    }
                    if(data.response == 3){
                    	swal(`Error`, data.licmsg, `error`, {
                            button: false,
                            closeOnClickOutside: false,
                            timer: 5000
                        }).then(() => {
                            location.reload()
                        });
                    }
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    swal(`Error`, `Error parsing data.`, `error`, {
                        button: false,
                        closeOnClickOutside: false,
                        timer: 3000
                    }).then(() => {
                        location.reload()
                    });
                },
                complete: function(){
            
            	}
            });
        }
        getD()
    });
</script>