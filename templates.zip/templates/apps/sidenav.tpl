<div class="main-sidebar sidebar-style-2">
<aside id="sidebar-wrapper">

<div class="sidebar-brand">
<a href="/">
{$s_logo}
<span class="hehe">{$site_name}</span>
</a>
</div>

<ul class="sidebar-menu">
{if $user_id_2=='1' || $user_level_2=='superadmin' || $user_level_2 == 'reseller'}
<li class="menu-header">Main</li>
<li><a class="nav-link" href="dashboard"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
<li class="dropdown">
<a href="" class="nav-link has-dropdown"><i class="fas fa-user-plus"></i><span>Create</span></a>
<ul class="dropdown-menu">
<li><a class="nav-link" href="add-user">User</a></li>
<li><a class="nav-link" href="add-reseller">Reseller</a></li>
</ul>
</li>
<li class="dropdown">
<a href="" class="nav-link has-dropdown"><i class="fas fa-users-cog"></i><span>Manage</span></a>
<ul class="dropdown-menu">
<li><a class="nav-link" href="view-user">User List</a></li>
<li><a class="nav-link" href="view-reseller">Reseller List</a></li>
</ul>
</li>
<li class="dropdown">
<a href="" class="nav-link has-dropdown"><i class="fas fa-clipboard-list"></i><span>Logs</span></a>
<ul class="dropdown-menu">
<li><a class="nav-link" href="log-activity">Activity Log</a></li>
<li><a class="nav-link" href="log-bulk">Bulk Log</a></li>
<li><a class="nav-link" href="log-credit">Credits Log</a></li>
<li><a class="nav-link" href="log-deleted">Delete Log</a></li>
</ul>
</li>
<li><a class="nav-link" href="privacy-policy"><i class="fas fa-shield-alt"></i> <span>Privacy Policy</span></a></li>
{/if}
{if $user_id_2=='1' || $user_level_2=='superadmin'}
<li class="menu-header">Panel</li>
<li><a class="nav-link" href="server"><i class="fas fa-server"></i> <span>Servers</span></a></li>
<li><a class="nav-link" href="dns"><i class="fas fa-cloud"></i> <span>Dns</span></a></li>
<li><a class="nav-link" href="notification"><i class="fas fa-bell"></i> <span>Notification</span></a></li>
<li><a class="nav-link" href="json"><i class="fas fa-code"></i> <span>Json</span></a></li>
<li><a class="nav-link" href="settings"><i class="fas fa-cog"></i> <span>Settings</span></a></li>

<div class="mt-4 mb-4 p-3 hide-sidebar-mini">
<a href="javascript:void(0)" class="btn btn-outline-primary btn-sm btn-block btn-icon-split btn-genuine" style="white-space: initial;">
PANEL FROM SHACKS DEV
</a>
</div>
{/if}
{if $user_id_2=='2' || $user_level_2=='developer'}
<li class="menu-header">Main</li>
<li><a class="nav-link" href="dashboard"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
<li class="menu-header">Panel</li>
<li><a class="nav-link" href="developer-settings"><i class="fas fa-cog"></i> <span>Settings</span></a></li>
{/if}
</ul>
</aside>
</div>

<a class="faz" href="#" onclick="return false;" type="button" data-theme-toggle><i id="xtoggle"></i></a>