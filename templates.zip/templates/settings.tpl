
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>{$site_name} — {$site_description}</title>
<link rel="shortcut icon" href="{$site_logo}" type="image/x-icon">
<link rel="icon" href="{$site_logo}" type="image/x-icon">

<link rel="stylesheet" href="/dist/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="/dist/modules/bootstrap-social/bootstrap-social.css">
<link rel="stylesheet" href="/dist/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-bs4.css">

<link rel="stylesheet" href="/dist/css-{$site_theme}/style.css">
<link rel="stylesheet" href="/dist/css-{$site_theme}/components.css">
{include file='css/custom_css.tpl'}
</head>

<body>

<div class="main-wrapper">
{include file='apps/topnav.tpl'}
{include file='apps/sidenav.tpl'}

<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Panel Settings</h1>
        </div>
        <div class="section-error">
            <div class="errors"></div>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Website</h5><br>
                            <form class="websettings" accept-charset="UTF-8" autocomplete="off">
                                <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                                <input type="hidden" name="notetitle" id="notetitle" value="{$site_note}">
                                <input type="hidden" name="submitted" id="submitted" value="web_settings">
                                <div class="form-group">
                                    <label for="title">Title</label>
                                    <input id="title" type="text" value="" class="form-control title" name="title" tabindex="1">
                                </div>
                                <div class="form-group">
                                    <label for="description">Description</label>
                                    <input id="description" type="text" value="" class="form-control description" name="description" tabindex="1">
                                </div>
                                <div class="form-group">
                                    <label for="owner">Owner</label>
                                    <input id="owner" type="text" value="" class="form-control owner" name="owner" tabindex="1">
                                </div>
                                <div class="form-group">
                                    <label for="images">Logo (Allowed Extension: gif, jpeg, jpg, png), 2MB</label>
                                    <input type="file" id="images" name="images[]" class="input-file">
                                    <div class="input-group">
                                        <input type="text" class="form-control" disabled placeholder="Upload Logo" tabindex="1">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary upload-field" type="button"><i class="fa fa-search"></i> Browse</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="logoshow">Logo Show</label>
                                    <select class="form-control" name="logoshow">
                                        <option class="logoshow" value="" selected=""></option>
                                        <option value="1">On</option>
                                        <option value="0">Off</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="maintenance">Maintenance</label>
                                    <select class="form-control" name="maintenance">
                                        <option class="maintenance" value="" selected=""></option>
                                        <option value="1">On</option>
                                        <option value="0">Off</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="theme">Theme</label>
                                    <select id="theme" class="form-control" name="theme">
                                        <option class="theme" value="" selected=""></option>
                                        <option value="default">Default</option>
                                        <option value="cyan">Cyan</option>
                                        <option value="dark">Dark</option>
                                        <option value="green">Green</option>
                                        <option value="orange">Orange</option>
                                        <option value="pink">Pink</option>
                                        <option value="red">Red</option>
                                        <option value="yellow">Yellow</option>
                                        <option value="blue">Blue</option>
                                        <option value="purple">Purple</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="note">Login Note</label>
                                    <textarea id="note" class="summernote" name="note"></textarea>
                                </div>
                                <div class="form-group" id="websettings">
                                    <button type="button" class="btn btn-primary btn-confirm-web" tabindex="4"> Confirm</button>
                                    <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                                    <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                 <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Download (Max: 3)</h5><br>
                        <div class="alert alert-primary" role="alert">
                            <h6 class="alert-heading"><i class="fas fa-book"></i> Note </h6>
                            <code>Max Download Links</code> : 3<br>
                            Fill up the form show next download form<br>
                        </div>
                        <form action="" class="downloadsettings" autocomplete="off">
                            <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                            <input type="hidden" name="submitted" id="submitted" value="app_update">
                            <div class="form-group download1">
                                <label>Download No.1</label>
                                <input type="text" placeholder="Enter download name" value="" class="form-control download1_name" name="download1_name" tabindex="1">
                                <br>
                                <input type="text" placeholder="Enter download link" value="" class="form-control download1_url" name="download1_url" tabindex="1">
                            </div>
                            <div class="form-group download2 d-none">
                                <label>Download No.2</label>
                                <input type="text" placeholder="Enter download name" value="" class="form-control download2_name" name="download2_name" tabindex="1">
                                <br>
                                <input type="text" placeholder="Enter download link" value="" class="form-control download2_url" name="download2_url" tabindex="1">
                            </div>
                            <div class="form-group download3 d-none">
                                <label>Download No.3</label>
                                <input type="text" placeholder="Enter download name" value="" class="form-control download3_name" name="download3_name" tabindex="1">
                                <br>
                                <input type="text" placeholder="Enter download link" value="" class="form-control download3_url" name="download3_url" tabindex="1">
                            </div>
                            <div class="form-group" id="downloadsettings">
                                <button type="button" class="btn btn-primary btn-confirm-app" tabindex="4"> Confirm</button>
                                <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                                <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">User Settings</h5><br>
                        <form action="" class="usersettings" autocomplete="off">
                            <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                            <input type="hidden" name="submitted" id="submitted" value="user_settings">
                            <div class="form-group">
                                <label for="prefix">Prefix</label>
                                <select class="form-control" name="prefix">
                                    <option class="prefix" value="" selected=""></option>
                                    <option value="1">On</option>
                                    <option value="0">Off</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="uprefix">Username Prefix</label>
                                <input id="uprefix" type="text" value="" class="form-control uprefix" name="uprefix" tabindex="1">
                            </div>
                            <div class="form-group">
                                <label for="trialdur">Trial Duration</label>
                                <select class="form-control" id="trialdur" name="trialdur">
                                    <option class="trialdur" value="" disabled selected></option>
                                    <option value="1">1 Hour</option>
                                    <option value="2">2 Hours</option>
                                    <option value="3">24 Hours</option>
                                    <option value="4">30 Minutes</option>
                                </select>
                            </div>
                            <div class="form-group" id="usersettings">
                                <button type="button" class="btn btn-primary btn-confirm-user" tabindex="4"> Confirm</button>
                                <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                                <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Vpn</h5><br>
                    <div class="alert alert-primary" role="alert">
                        <h6 class="alert-heading"><i class="fas fa-book"></i> Note </h6>
                        <code>Max Vpn Sessions</code> : Limit max vpn session per account.<br>
                        <code>Reset All Vpn Sessions</code> : Reset all vpn sessions, this won't logout already logged in users.
                        Restart all your vpn servers after doing this. It will reset Online user counter too.<br>
                    </div>
                    <form class="vpnsettings" accept-charset="UTF-8" autocomplete="off">
                        <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                        <input type="hidden" name="submitted" id="submitted" value="vpn_session">
                        <div class="form-group">
                            <label for="sessions">Max Vpn Sessions</label>
                            <input id="sessions" type="number" value="" min="2" class="form-control sessions" name="sessions" tabindex="1">
                        </div>
                        <div class="form-group">
                            <label for="resetvpnsessions">Reset Vpn Sessions</label>
                            <select class="form-control" name="resetvpnsessions">
                                <option value="0">No</option>
                                <option value="1">Yes</option>
                            </select>
                        </div>
                        <div class="form-group" id="vpnsettings">
                            <button type="button" class="btn btn-primary btn-confirm-session" tabindex="4"> Confirm</button>
                            <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                            <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Trial</h5><br>
                    <div class="alert alert-primary" role="alert">
                        <h6 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Warning </h6>
                        <p>This will <code>delete</code> all the trial accounts created.</p>
                    </div>
                    <form class="trialsettings" accept-charset="UTF-8" autocomplete="off">
                        <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                        <input type="hidden" name="submitted" id="submitted" value="trial_reset">
                        <div class="form-group">
                            <input type="text" class="form-control trialcounter" readonly="">
                        </div>
                        <div class="form-group" id="trialsettings">
                            <button type="button" class="btn btn-primary btn-confirm-trial" tabindex="4"> Confirm</button>
                            <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                            <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Device Reset</h5><br>
                    <div class="alert alert-danger" role="alert">
                        <h6 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Warning </h6>
                        <p>This will <code>RESET</code> all devices in all vpn accounts</p>
                    </div>
                    <form class="clrdevice" accept-charset="UTF-8" autocomplete="off">
                        <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                        <input type="hidden" name="submitted" id="submitted" value="reset_device">
                        <div class="form-group" id="deletedevice">
                            <button type="button" class="btn btn-primary btn-confirm-clrdevice" tabindex="4"> Confirm</button>
                            <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                            <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
             <div class="card card-primary">
            <div class="card-header">
            <h2 class="section-title">Expired Delete</h2>
            </div>
                <div class="card-body">
                    <div class="alert alert-danger" role="alert">
                        <h6 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Warning </h6>
                        <p>This will <code>DELETE</code> all expired accounts.</p>
                        <p>This will <code>NOT</code> reflect in deleted logs.</p>
                    </div>
                    <form class="deletexpired" accept-charset="UTF-8" autocomplete="off">
                        <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
                        <input type="hidden" name="submitted" id="submitted" value="delete_expired">
                        <div class="form-group" id="delete_xpired">
                            <button type="button" class="btn btn-primary btn-confirm-delxpired" tabindex="4"> Confirm</button>
                            <button type="submit" class="btn btn-success btn-confirm-auth d-none" tabindex="4"> Authorize</button>
                            <button type="button" class="btn btn-confirm-cancel btn-danger d-none" tabindex="4">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
           <style>
    #api-list {
        background-color: #007bff; /* প্রাইমারি ব্লু ব্যাকগ্রাউন্ড */
        color: white; /* সাদা টেক্সট */
        padding: 10px;
        border-radius: 5px;
        font-family: monospace;
    }
</style>

<div class="card card-primary">
    <div class="card-header">
        <h2 class="section-title">Panel all API</h2>
    </div>
    <div class="card-body">
        <div class="alert alert-primary" role="alert">
            <h6 class="alert-heading"><i class="fas fa-exclamation-triangle"></i> Your Panel API </h6>
            <pre id="api-list" class="bg-primary" class="alert-heading">
UNIVERSAL AUTH API :
https://angeltunnel.com/api/auth.php?username=%s&password=%s&device_id=%s&device_model=%s


JSON UPDATE API (GET) :
https://angeltunnel.com/api/files/app?json=xxxxxxxxxxxxxx


JSON UPDATE API (POST) : 
https://angeltunnel.com/api/files/update == FORM ENCODE : hash: HASHVALUE code: JSON-NEW-VALUE-HERE
            </pre>
        </div>
        
        <form class="deletexpired" accept-charset="UTF-8" autocomplete="off">
            <input type="hidden" name="_key" id="_key" value="{$firenet_encryptt}">
            <input type="hidden" name="submitted" id="submitted" value="delete_expired">
            <div class="form-group" id="delete_xpired">
                <button type="button" class="btn btn-primary btn-copy-api" tabindex="4">Copy API</button>
            </div>
        </form>
    </div>
</div>

<script>
document.querySelector('.btn-copy-api').addEventListener('click', function() {
    const apiList = document.getElementById('api-list').innerText;
    navigator.clipboard.writeText(apiList).then(() => {
        alert('API list copied to clipboard!');
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
});
</script>
            </div>
            </div>
        </div>
    </section>
</div>

<div class="modal fade normal-modalize" role="dialog" aria-labelledby="smallmodal">
<div class="modal-dialog modal-md normal-modal-dialog" role="document">
<div class="modal-content normal-modal-content">
<div class="modal-header normal-modal-header">
<h5 class="modal-title normal-modal-title"></h5>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body normal-modal-body">
<div class="modal-error normal-modal-error"></div>
<div class="modal-html normal-modal-html"></div>
</div>
</div>
</div>
</div>

<div class="modal fade search-modalize" role="dialog" aria-labelledby="smallmodal">
<div class="modal-dialog modal-md search-modal-dialog" role="document">
<div class="modal-content search-modal-content">
<div class="modal-header search-modal-header">
<h5 class="modal-title search-modal-title"></h5>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body search-modal-body">
<div class="modal-error search-modal-error"></div>
<div class="modal-html search-modal-html"></div>
</div>
</div>
</div>
</div>

<script src="/dist/modules/jquery.min.js"></script>
<script src="/dist/modules/popper.js"></script>
<script src="/dist/modules/tooltip.js"></script>
<script src="/dist/modules/bootstrap/js/bootstrap.min.js"></script>
<script src="/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
<script src="/dist/modules/moment.min.js"></script>
<script src="/dist/modules/sweetalert/sweetalert.min.js"></script>
<script src="/dist/modules/time.js"></script>
<script src="/dist/js/stisla.js"></script>

<script src="/dist/modules/chart.min.js"></script>
<script src="/dist/modules/datatables/datatables.min.js"></script>
<script src="/dist/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="/dist/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
<script src="/dist/modules/jquery-ui/jquery-ui.min.js"></script>
<script src="/dist/bootstrap/assets/jqueryform/jquery.form.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote-bs4.js"></script>
<script src="/dist/modules/select2.full.min.js"></script>

<script src="/dist/js/clipboard.min.js"></script>
<script src="/dist/js/scripts.js"></script>
<script src="/dist/js/custom-select.js"></script>
{include file='js/page/custom_js.tpl'}
{include file='js/page/notification_js.tpl'}
{include file='js/page/settings_js.tpl'}
{include file='js/page/search_js.tpl'}
</body>
</html>