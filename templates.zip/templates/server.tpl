
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>{$site_name} — {$site_description}</title>
<link rel="shortcut icon" href="{$site_logo}" type="image/x-icon">
<link rel="icon" href="{$site_logo}" type="image/x-icon">

<link rel="stylesheet" href="/dist/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/timeago.js/4.0.2/timeago.min.js" integrity="sha512-SVDh1zH5N9ChofSlNAK43lcNS7lWze6DTVx1JCXH1Tmno+0/1jMpdbR8YDgDUfcUrPp1xyE53G42GFrcM0CMVg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<link rel="stylesheet" href="/dist/modules/bootstrap-social/bootstrap-social.css">
<link rel="stylesheet" href="/dist/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/summernote/summernote-bs4.css">

<link rel="stylesheet" href="/dist/css-{$site_theme}/style.css">
<link rel="stylesheet" href="/dist/css-{$site_theme}/components.css">
{include file='css/custom_css.tpl'}
</head>
<body>

<div class="main-wrapper">
{include file='apps/topnav.tpl'}
{include file='apps/sidenav.tpl'}

<div class="main-content">
<section class="section">
<div class="section-header">
<h1>Server Management</h1>
</div>
<div class="section-body">
<div class="row">
<div class="col-md-4">
<div class="card">
<div class="card-body">
<div class="section-error">
<div class="errors"></div>
</div>
<div class="alert alert-warning text-center add-server-alert d-none" role="alert">
<i class="fas fa-exclamation-triangle"></i>
<br>
<strong>SERVER INSTALLER IS UNDER MAINTENANCE<br>please try again later. </strong>
</div>

<div class="alert alert-info add-server-message d-none" role="alert">
<div class="add-server-content"> <i class="fas fa-exclamation-triangle"></i> 
<strong>You selected <code>V2RAY</code> installer, make sure you have a v2ray supported app.</strong>
</div>
</div>

<form action="" class="add-server d-none" autocomplete="off">
<input type="hidden" name="submitted" name="submitted" value="add_server">
<input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
<div class="row">
<div class="col-md-6">
<div class="form-group">
<label for="servername">Server Name</label>
<input id="servername" type="text" class="form-control servername" name="servername" tabindex="1" required="">
</div>
<div class="form-group">
<label for="serverip">Server Host/Ip</label>
<input id="serverip" type="text" class="form-control serverip" name="serverip" tabindex="1" required="">
</div>
<div class="form-group">
<label for="serverpass">Server Password</label>
<input id="serverpass" type="text" class="form-control serverpass" name="serverpass" tabindex="1" required="">
</div>
<div class="form-group">
<label for="serveruser">Server User</label>
<input id="serveruser" type="text" class="form-control serveruser" name="serveruser" tabindex="1" value="root" required="">
</div>
<div class="form-group">
<label for="servertype">Server Vpn Type</label>
<select class="form-control" id="servertype" name="servertype">
<option disabled>----- UBUNTU (18 to 20) -----</option>
<option value="1" selected="" class="text-primary">UBUNTU OPENVPN (HTTP)</option>
<option value="2" class="text-primary">UBUNTU OPENCONNECT (HTTP)</option>
<!--option value="3" class="text-primary">UBUNTU SSH (HTTP)</option-->
<option value="4" class="text-primary">UBUNTU OPENVPN (WS)</option>
<option value="5" class="text-primary">UBUNTU OPENCONNECT (WS)</option>
<option value="41" class="text-primary">UBUNTU HYSTERIA (UDP)</option>
<option value="51" class="text-primary">UBUNTU SOCKSIP (UDP)</option>
<!--option value="6" class="text-primary">UBUNTU SSH (WS)</option>
<option value="7" class="text-primary">UBUNTU PPTP</option-->
<option disabled>-----DEBIAN (9 to 11)-----</option>
<option value="8" class="text-warning">DEBIAN OPENVPN (HTTP)</option>
<option value="9" class="text-warning">DEBIAN OPENCONNECT (HTTP)</option>
<!--option value="10" class="text-warning">DEBIAN SSH (HTTP)</option-->
<option value="11" class="text-warning">DEBIAN OPENVPN (WS)</option>
<option value="12" class="text-warning">DEBIAN OPENCONNECT (WS)</option>
<option value="42" class="text-warning">DEBIAN HYSTERIA (UDP)</option>
<option value="62" class="text-warning">DEBIAN HYSTERIA (UDP FREE)</option>
<option value="31" class="text-warning">DEBIAN XRAY</option-->
<option value="13" class="text-warning">DEBIAN AIO (WS)</option>
<option value="81" class="text-warning">DEBIAN SSH (WS)</option>
<!--option value="13" class="text-warning">DEBIAN SSH (WS)</option>
<option value="14" class="text-warning">DEBIAN PPTP</option-->
<option disabled>-----CENTOS (7)-----</option>
<option value="15" class="text-danger">CENTOS OPENVPN (HTTP)</option>
<!--option value="16" class="text-danger">CENTOS OPENCONNECT (HTTP)</option>
<option value="17" class="text-danger">CENTOS SSH (HTTP)</option-->
<option value="18" class="text-danger">CENTOS OPENVPN (WS)</option>
<option value="43" class="text-danger">CENTOS HYSTERIA (UDP)</option>
<!--option value="19" class="text-danger">CENTOS OPENCONNECT (WS)</option-->
<!--option value="20" class="text-danger">CENTOS SSH (WS)</option>
<option value="21" class="text-danger">CENTOS PPTP</option-->
</select>
</div>
<div class="form-group">
<label for="serverobfs">Custom Hysteria AUTH</label>
<input id="serverauthstr" type="text" class="form-control serverauthstr" name="serverauthstr" tabindex="1" value="dxplusdev" required="">
</div>
<div class="form-group">
<label for="hysteriatype">Hysteria Type</label>
<select class="form-control" id="hysteriatype" name="hysteriatype">
<option value="1" class="text-primary" selected>DEFAULT HYSTERIA</option>
<option value="2" class="text-primary">ZI HYSTERIA</option>
</select>
</div>
</div>

<div class="col-md-6">
<div class="form-group">
<label for="servertcp">Custom Tcp Port</label>
<input id="servertcp" type="text" class="form-control servertcp" name="servercustomtcp" tabindex="1" value="1194" required="">
</div>
<div class="form-group">
<label for="serverudp">Custom Udp Port</label>
<input id="serverudp" type="text" class="form-control serverudp" name="servercustomudp" tabindex="1" value="110" required="">
</div>
<div class="form-group">
<label for="serverssl">Custom Ssl Port</label>
<input id="serverssl" type="text" class="form-control serverssl" name="servercustomssl" tabindex="1" value="443" required="">
</div>
<div class="form-group">
<label for="servervless">Custom Vless Port</label>
<input id="servervless" type="text" class="form-control servervless" name="servercustomvless" tabindex="1" value="442" required="">
</div>
<div class="form-group">
<label for="serverport">Server Port</label>
<input id="serverport" type="text" class="form-control serverport" name="serverport" tabindex="1" value="22" required="">
</div>
<div class="form-group">
<label for="serverobfs">Custom Hysteria OBFS</label>
<input id="serverobfs" type="text" class="form-control serverobfs" name="serverobfs" tabindex="1" value="dxplusdev" required="">
</div>
</div>
</div>
<div class="form-group">
<button type="submit" class="btn btn-primary btn-block btn-add-server" tabindex="4">Install</button>
</div>
</form>
</div>
</div>
<div class="card">
<div class="card-body">
<a href="https://drive.google.com/uc?export=download&id=1IQP3ZfUNDrMyCQzW_j6UbvEvyUgYnVE6" target="_blank" class="btn btn-primary btn-block">OVPN Config</a>
<!--a href="https://drive.google.com/uc?export=download&id=1CQY_uuH9lTLNCEhVVnSjZdkMfD_ne8Gh" target="_blank" class="btn btn-primary btn-block">OVPN Config (Debian)</a-->
</div>
</div>
</div>
<div class="col-md-8">
<div class="card">
<div class="card-body">
<div class="alert alert-danger" role="alert">
<strong>SERVER STATUS INDICATOR</strong>
<ul>
<li><code>ACTIVE</code> - <small>ALL SERVICE GOOD, TOTAL USER WILL SHOW SOMETIME LET THE SERVER DO HIS WORK AND WAIT.</small></li>
<li><code>INACTIVE</code> - <small>SOME SERVICE IS NOT GOOD, RESTART THE SERVER.</small></li>
<li><code>OFFLINE</code> - <small>VPS PROVIDER SHUTDOWN THE SERVER OR DELETED OR DISABLED IT, GET A NEW SERVER.</small></li>
</ul> 
</div>
<div class="table-responsive">
<table class="table table-listserver" style="width: 100%">
<thead>
<tr>
<th>    
<div class="custom-checkbox custom-control">
<input type="checkbox" class="custom-control-input checkbox-parent" id="checkbox-all">
<label for="checkbox-all" class="custom-control-label">&nbsp;</label>
</div>
</th>
<th>Name</th>
<th>Service</th>
<th>Status</th>
<th>Location</th>
<th>Action</th>
</tr>
</thead>
</table>
</div>
</div>
</div>
</div>
</div>
<button class="btn btn-primary btn-circle btn-sm float-right btn-multi-delete d-none"><i class="fa fa-trash" aria-hidden="true" style="font-size: 20px; padding-top: 5px"></i></button>
</div>
</section>
</div>

<div class="modal fade modalize" role="dialog" aria-labelledby="smallmodal">
<div class="modal-dialog modal-md" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title"></h5>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
<div class="modal-error"></div>
<div class="modal-html"></div>
</div>
</div>
</div>
</div>

<div class="modal fade search-modalize" role="dialog" aria-labelledby="smallmodal">
<div class="modal-dialog modal-md search-modal-dialog" role="document">
<div class="modal-content search-modal-content">
<div class="modal-header search-modal-header">
<h5 class="modal-title search-modal-title"></h5>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body search-modal-body">
<div class="modal-error search-modal-error"></div>
<div class="modal-html search-modal-html"></div>
</div>
</div>
</div>
</div>

<script src="/dist/modules/jquery.min.js"></script>
<script src="/dist/modules/popper.js"></script>
<script src="/dist/modules/tooltip.js"></script>
<script src="/dist/modules/bootstrap/js/bootstrap.min.js"></script>
<script src="/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
<script src="/dist/modules/moment.min.js"></script>
<script src="/dist/modules/sweetalert/sweetalert.min.js"></script>
<script src="/dist/modules/time.js"></script>
<script src="/dist/js/stisla.js"></script>

<script src="/dist/modules/chart.min.js"></script>
<script src="/dist/modules/datatables/datatables.min.js"></script>
<script src="/dist/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="/dist/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
<script src="/dist/modules/jquery-ui/jquery-ui.min.js"></script>

<script src="/dist/bootstrap/assets/jqueryform/jquery.form.js"></script>
<script src="/dist/modules/summernote/summernote-bs4.min.js"></script>

<script src="/dist/js/clipboard.min.js"></script>
<script src="/dist/js/scripts.js"></script>
<script src="/dist/js/custom-select.js"></script>
{include file='js/page/custom_js.tpl'}
{include file='js/page/notification_js.tpl'}
{include file='js/page/server_js.tpl'}
{include file='js/page/search_js.tpl'}
</body>
</html>