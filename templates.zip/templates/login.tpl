<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
<title>{$site_name} — {$site_description}</title>
<link rel="shortcut icon" href="{$site_logo}" type="image/x-icon">
<link rel="icon" href="{$site_logo}" type="image/x-icon">

<link rel="stylesheet" href="/dist/modules/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="/dist/modules/bootstrap-social/bootstrap-social.css">
<link rel="stylesheet" href="/dist/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">
<link rel="stylesheet" href="/dist/modules/summernote/summernote-bs4.css">

<link rel="stylesheet" href="{$base_url}dist/css-{$site_theme}/style.css">
<link rel="stylesheet" href="{$base_url}dist/css-{$site_theme}/components.css">

<style>
    .hehe{
        color: #ffff;
         background-image: -webkit-linear-gradient(30deg, #f35626, #feab3a);
         -webkit-background-clip: text;
         -webkit-text-fill-color: transparent;
         -webkit-animation: hue 10s infinite linear;
    }
    @-webkit-keyframes hue{
        from{
            -webkit-filter: hue-rotate(0deg);
        }
        to{
            -webkit-filter: hue-rotate(-360deg);
        }
</style>

{include file='css/custom_css.tpl'}
</head>
<body>
    <a class="faz" href="#" onclick="return false;" type="button" data-theme-toggle><i id="xtoggle"></i></a>
<div id="app">
<section class="section">
<div class="container mt-5">
<div class="row">
<div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
<div class="login-brand">
<img src="{$site_logo}" alt="logo" width="120">
</div>
{$mainte}
<div class="card card-primary">
<div class="card-body">
    
{$login_note}

    <form method="post" class="authenticate" autocomplete="off">
        <div class="errors"></div>
    
        <input type="hidden" id="submitted" name="submitted" value="login_account" />
        <input type="hidden" id="code" name="code" value="{$code}" />
        <input type="hidden" id="category" name="category" value="{$login_encrypt}" />
        <input type="hidden" name="_key" id="_key" value="{$firenet_encrypt}">
        <div class="form-group">
            <label for="user_name">Username</label>
            <input type="text" class="form-control" name="user_name" id="user_name" value="{$user_name}" tabindex="1" autofocus>
        </div>
        <div class="form-group">
            <label for="user_pass">Password</label>
            
            <div class="input-group colorpickerinput">
            <input type="password" class="form-control" name="user_pass" id="user_pass" tabindex="1" autofocus>
                <div class="input-group-append">
                    <div class="input-group-text text-primary" style="cursor: pointer;">
                        <span class="password-toggle-icon"><i class="fas fa-eye"></i></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-outline-primary btn-lg btn-block btn-submit" tabindex="4">Login</button>
        </div>
    </form>

{$app1}
{$app2}
{$app3}

</div>
</div>
</div>
</div>
</div>
</section>
<footer class="footer">
<div class="simple-footer">
<span class="hehe">{$site_name}</span><br>
<span class="text-muted">Copyright &copy; <script>document.write(new Date().getFullYear())</script> - <a href="/privacy-policy" target="_blank">Privacy Policy</a></span>
</div>
</footer>
</div>

<div class="modal fade modalize" role="dialog" aria-labelledby="smallmodal">
<div class="modal-dialog modal-md" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title"></h5>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
<div class="modal-error"></div>
<div class="modal-html"></div>
</div>
</div>
</div>
</div>

<script src="/dist/modules/jquery.min.js"></script>
<script src="/dist/modules/popper.js"></script>
<script src="/dist/modules/tooltip.js"></script>
<script src="/dist/modules/bootstrap/js/bootstrap.min.js"></script>
<script src="/dist/modules/nicescroll/jquery.nicescroll.min.js"></script>
<script src="/dist/modules/moment.min.js"></script>
<script src="/dist/modules/sweetalert/sweetalert.min.js"></script>
<script src="/dist/modules/time.js"></script>
<script src="/dist/js/stisla.js"></script>

<script src="/dist/modules/chart.min.js"></script>
<script src="/dist/modules/datatables/datatables.min.js"></script>
<script src="/dist/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="/dist/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
<script src="/dist/modules/jquery-ui/jquery-ui.min.js"></script>
<script src="/dist/bootstrap/assets/jqueryform/jquery.form.js"></script>
<script src="/dist/modules/summernote/summernote-bs4.min.js"></script>

<script src="/dist/js/clipboard.min.js"></script>
<script src="/dist/js/scripts.js"></script>
<script src="/dist/js/custom.js"></script>
<script src="/dist/js/custom-select.js"></script>
{include file='js/page/custom_js.tpl'}
<script>
function errorMessage(type, title, message) {
    $(".errors").html('<div class="alert alert-' + type + ' alert-has-icon"><div class="alert-icon"><i class="far fa-lightbulb"></i></div><div class="alert-body"><button class="close" data-dismiss="alert"><span>&times;</span></button><div class="alert-title">' + title + '</div>' + message + '</div></div>').slideDown();
}

$('document').ready(function()
{
    var $form = $('.authenticate');
	$form.ajaxForm({
		type: "POST",
		url: "{$base_url}serverside/forms/login.php",
		data: $form.serialize(),
		dataType: "JSON",
		cache: false,
		beforeSend: function() {
			$(".btn-submit").addClass("btn-progress");
		},
		success: function(data){
			if(data.response == 1){
    			errorMessage('success', 'Success', data.msg);
    			setTimeout(() => {
                  location.reload()
                }, 2000)
    		}
    		if(data.response == 2){
    			errorMessage('warning','Oops', data.msg);
    		}
    		if(data.response == 3){
    			errorMessage('danger','Error', data.errormsg);
    		}
    		if(data.response == 4){
    			errorMessage('success', 'Success', data.msg);
    			setTimeout(() => {
                  location.href = "confirmation?id=" + data.id
                }, 2000)
    		}
		},
		error: function(jqXHR, textStatus, errorThrown) {
			swal(`Failed`, `Failed getting data from AJAX.`, `warning`, {
                button: false,
                closeOnClickOutside: false,
                timer: 3000
            }).then(() => {
                location.reload()
            });
		},
		complete: function(){
			$(".btn-submit").removeClass("btn-progress");
		}
	});	
	
	const passwordField = document.getElementById("user_pass");
    const togglePassword = document.querySelector(".password-toggle-icon i");

    togglePassword.addEventListener("click", function () {
      if (passwordField.type === "password") {
        passwordField.type = "text";
        togglePassword.classList.remove("fa-eye");
        togglePassword.classList.add("fa-eye-slash");
      } else {
        passwordField.type = "password";
        togglePassword.classList.remove("fa-eye-slash");
        togglePassword.classList.add("fa-eye");
      }
    });
});
</script>

</body>
</html>