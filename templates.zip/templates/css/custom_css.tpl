<style>
/*

WAG KA NA IIYAK HAHAHAHA 😂😂
TORNADO2X NAAAAA HAHAHAHA 😂😂
NAPAG-UTUSAN LANG HAHAHAHA 😂😂
HINDI NAMAN NAGPAPABAYAD SI STISLA HAHAHAHA 😂😂
MAGKA-IBA CODES NATIN HAHAHAHA 😂😂

-Core4VPN 🔥🔥🔥🔥

*/

[data-theme="light"]  {
  filter: invert(0%) hue-rotate(0deg);
}

[data-theme="dark"] {
  filter: invert(100%) hue-rotate(180deg);
}

[data-theme="dark"] img{
  filter: invert(100%) hue-rotate(180deg);
}

.btn-circle.btn-sm{
    width:50px;height:50px;
    padding:7px 10px;
    border-radius:25px;
    font-size:10px;
    text-align:center;
    position:fixed;
    bottom:8px;right:8px
}

.hehe{
    color:#ffff;
    background-image:-webkit-linear-gradient(30deg,#f35626,#feab3a);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    -webkit-animation:10s linear infinite hue
}

.avatar{
    background: none !important;
}

.input-file { visibility: hidden; position: absolute;}

@-webkit-keyframes hue{
    from{
        -webkit-filter:hue-rotate(0deg)
    }
    to{
        -webkit-filter:hue-rotate(-360deg)
        
    }
    
}

*{
    scrollbar-width:auto;
    scrollbar-color:#9b9b9b #ffffff
}
::-webkit-scrollbar{
    width:10px
}

::-webkit-scrollbar-track{
    background:#fff
}

::-webkit-scrollbar-thumb{
    background-color:#9b9b9b;
    border-radius:10px;
    border:3px solid #fff
}

.faz {
   width: 35px;
   height: 35px;
   background-color: var(--primary);
   border-radius: 50%;
   box-shadow: 0 4px 10px 0 #666;
   
   font-size: 15px;
   line-height: 35px;
   color: white;
   text-align: center;
   
   position: fixed;
   right: 20px;
   bottom: 20px;
   z-index: 5000;
   
  transition: all 0.1s ease-in-out;
}

.faz:hover {
   box-shadow: 0 4px 14px 0 #666;
   transform: scale(1.05);
   color: #F0F0F0 !important;
}
</style>