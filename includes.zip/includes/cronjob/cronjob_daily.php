<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Secret key for URL-based cron
define('CRON_SECRET', 'angeltunnel2026cron');

$secret = isset($_GET['key']) ? $_GET['key'] : '';

function get_client_ip() {
    if (getenv('HTTP_CLIENT_IP')) return getenv('HTTP_CLIENT_IP');
    if (getenv('HTTP_X_FORWARDED_FOR')) return getenv('HTTP_X_FORWARDED_FOR');
    if (getenv('HTTP_X_FORWARDED')) return getenv('HTTP_X_FORWARDED');
    if (getenv('HTTP_FORWARDED_FOR')) return getenv('HTTP_FORWARDED_FOR');
    if (getenv('HTTP_FORWARDED')) return getenv('HTTP_FORWARDED');
    if (getenv('REMOTE_ADDR')) return getenv('REMOTE_ADDR');
    return 'UNKNOWN';
}

$ip = get_client_ip();

if ($ip == 'UNKNOWN' || $secret === CRON_SECRET) {

    require_once __DIR__ . '/../db_config.php';

    $conn = mysqli_connect($DB_host, $DB_user, $DB_pass, $DB_name);
    if (!$conn) {
        die('DB connection failed: ' . mysqli_connect_error());
    }

    $thirtydays = date('Y-m-d H:i:s', strtotime('+30 days'));

    // Deduct 1 full day (86400 seconds) from ALL non-admin active accounts
    // regardless of whether they are connected or not
    mysqli_query($conn, "UPDATE users 
        SET duration = duration - 86400 
        WHERE user_id > 1 
        AND user_level != 'superadmin' 
        AND is_freeze = 0 
        AND duration > 0");

    // Clamp any negatives to 0
    mysqli_query($conn, "UPDATE users 
        SET duration = 0 
        WHERE user_id > 1 
        AND user_level != 'superadmin' 
        AND is_freeze = 0 
        AND duration < 1");

    // Find and remove expired non-admin accounts
    $rup = "is_groupname!='subadmin' AND is_groupname!='reseller' AND is_groupname!='subreseller' AND is_groupname!='administrator' AND is_groupname!='superadmin' AND is_groupname!='developer'";
    $rquery = mysqli_query($conn, "SELECT * FROM users WHERE user_id!=1 AND user_level!='superadmin' AND duration<1 AND $rup");

    $deleted = 0;
    while ($rad_row = mysqli_fetch_assoc($rquery)) {
        $rad_username = mysqli_real_escape_string($conn, $rad_row['user_name']);
        $u_id = intval($rad_row['user_id']);

        mysqli_query($conn, "INSERT INTO users_delete
            (delete_timestamp, user_id, user_name, user_pass, auth_vpn,
            user_email, full_name, regdate, ipaddress, lastlogin,
            timestamp, code, reset_code, is_groupname, is_active,
            is_freeze, last_freeze_date, is_validated, is_connected,
            is_offense, is_ban, suspended_date, duration, vip_duration,
            is_vip, private_duration, is_private, private_slot,
            private_control, credits, upline, login_status,
            last_active_time, user_level, status, device_id,
            device_model, device_connected)
            VALUES
            ('" . mysqli_real_escape_string($conn, $thirtydays) . "',
            '$u_id',
            '" . mysqli_real_escape_string($conn, $rad_row['user_name']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['user_pass']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['auth_vpn']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['user_email']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['full_name']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['regdate']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['ipaddress']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['lastlogin']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['timestamp']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['code']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['reset_code']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_groupname']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_active']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_freeze']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['last_freeze_date']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_validated']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_connected']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_offense']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_ban']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['suspended_date']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['duration']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['vip_duration']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_vip']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['private_duration']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['is_private']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['private_slot']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['private_control']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['credits']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['upline']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['login_status']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['last_active_time']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['user_level']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['status']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['device_id']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['device_model']) . "',
            '" . mysqli_real_escape_string($conn, $rad_row['device_connected']) . "')");

        mysqli_query($conn, "DELETE FROM radcheck WHERE username = '$rad_username'");
        mysqli_query($conn, "DELETE FROM users WHERE user_id = '$u_id'");
        $deleted++;
    }

    mysqli_close($conn);
    echo 'OK: Daily deduction done at ' . date('Y-m-d H:i:s') . ' | Expired accounts removed: ' . $deleted;

} else {
    echo '<script>alert("Unauthorized access detected. Your IP Address: ' . $ip . '"); window.location.href="https://www.google.com";</script>';
}
?>
