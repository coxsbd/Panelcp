<?php
include '../db_config.php';
require "mysql.class2.php";
$db = new mysql_db();
$db->InitDB($DB_host,$DB_user,$DB_pass,$DB_name);
$db->SetWebsiteName('octaviavpn.info');
$db->SetWebsiteTitle('Octavia VPN');

?>