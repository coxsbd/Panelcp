<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

echo "Step 1: Script started<br>";

// Test db_config.php path
$db_config_path = __DIR__ . '/../db_config.php';
echo "Step 2: Looking for db_config.php at: " . $db_config_path . "<br>";

if (!file_exists($db_config_path)) {
    die("ERROR: db_config.php NOT found at that path. Check your folder structure.");
}
echo "Step 3: db_config.php found OK<br>";

include $db_config_path;
echo "Step 4: db_config.php loaded OK<br>";
echo "DB Host: " . (isset($DB_host) ? $DB_host : 'NOT SET') . "<br>";
echo "DB User: " . (isset($DB_user) ? $DB_user : 'NOT SET') . "<br>";
echo "DB Name: " . (isset($DB_name) ? $DB_name : 'NOT SET') . "<br>";
echo "DB Pass: " . (isset($DB_pass) ? (strlen($DB_pass) > 0 ? '***SET***' : 'EMPTY') : 'NOT SET') . "<br>";

// Test MySQL connection
echo "Step 5: Testing DB connection...<br>";
$conn = @mysqli_connect($DB_host, $DB_user, $DB_pass, $DB_name);
if (!$conn) {
    die("ERROR: DB connection failed: " . mysqli_connect_error());
}
echo "Step 6: DB connected OK<br>";
mysqli_close($conn);

echo "<br><strong>All checks passed! DB is reachable.</strong>";
?>
