<?php
date_default_timezone_set('Africa/Kampala');
$DB_ip = "174.138.191.235";
$DB_host = "localhost";
$DB_user = "angeltun_angeltun";
$DB_pass = "angeltun_angeltun";
$DB_name = "angeltun_angeltun";

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if($mysqli->connect_error){
   die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
?>